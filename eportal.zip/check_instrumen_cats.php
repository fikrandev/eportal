<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT DISTINCT kategori, target_jabatan, target_dinilai FROM perf_instrumen WHERE target_dinilai LIKE '%Administrasi%' OR target_dinilai LIKE '%TU%' OR target_dinilai LIKE '%Semua%' OR target_dinilai LIKE '%Pustakawan%'");
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($res);
?>
