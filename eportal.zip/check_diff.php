<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
// Get Amaliya PTK ID
$stmt = $db->query("SELECT id FROM perf_ptk WHERE nama LIKE '%AMALIYA%' LIMIT 1");
$ptk_id = $stmt->fetchColumn();

// --- cetak_lampiran.php logic ---
// Query Manual Instruments (Page 1)
$stmtManualInst = $db->prepare("SELECT id, kategori, pertanyaan, bobot, skor_ya, target_dinilai FROM perf_instrumen WHERE periode_id = ? AND is_manual = 1 ORDER BY urutan ASC, id ASC");
$stmtManualInst->execute([$periode_id]);
$allManualInstRaw = $stmtManualInst->fetchAll(PDO::FETCH_ASSOC);

$stmtPTK = $db->prepare("SELECT pt.*, u.tupoksi, u.jabatan FROM perf_ptk pt JOIN users u ON pt.niy COLLATE utf8mb4_unicode_ci = u.username WHERE pt.id = ?");
$stmtPTK->execute([$ptk_id]);
$ptk = $stmtPTK->fetch(PDO::FETCH_ASSOC);
$ptk_jenis = trim($ptk['jenis_ptk'] ? $ptk['jenis_ptk'] : ($ptk['tupoksi'] ? $ptk['tupoksi'] : 'Guru'));

$main_manual = [];
$tugas_tambahan = [];
foreach ($allManualInstRaw as $inst) {
    $targetsStr = trim($inst['target_dinilai'] ? $inst['target_dinilai'] : 'Semua');
    $targets = array_map('trim', explode(',', $targetsStr));
    if ($targetsStr !== 'Semua' && !in_array('Semua', $targets) && !in_array($ptk_jenis, $targets)) {
        continue;
    }
    if ((float)$inst['bobot'] > 0) {
        $main_manual[] = $inst;
    } else {
        $tugas_tambahan[] = $inst;
    }
}

$grouped_manual = [];
foreach ($main_manual as $inst) {
    $kat = $inst['kategori'];
    if (!isset($grouped_manual[$kat])) {
        $grouped_manual[$kat] = ['total_bobot' => $inst['bobot'], 'achieved_score' => 0, 'max_score' => 0];
    } else {
        $grouped_manual[$kat]['total_bobot'] += $inst['bobot'];
    }
}

$stmtManual = $db->prepare("SELECT data FROM perf_penilaian_manual WHERE periode_id = ? AND ptk_id = ? LIMIT 1");
$stmtManual->execute([$periode_id, $ptk_id]);
$manualRow = $stmtManual->fetch(PDO::FETCH_ASSOC);
$manualData = $manualRow && $manualRow['data'] ? json_decode($manualRow['data'], true) : [];

foreach ($main_manual as $inst) {
    $kat = $inst['kategori'];
    $score = isset($manualData[$inst['id']]) ? (float)$manualData[$inst['id']] : 0;
    $skor_ya = (float)($inst['skor_ya'] > 0 ? $inst['skor_ya'] : 100);
    $grouped_manual[$kat]['achieved_score'] += $score;
    $grouped_manual[$kat]['max_score'] += $skor_ya;
}

echo "LAMPIRAN 1 (AMALIYA):\n";
foreach ($grouped_manual as $kat => $group) {
    $avg_score = $group['max_score'] > 0 ? ($group['achieved_score'] / $group['max_score']) * 100 : 0;
    $group_nilai = $avg_score * ($group['total_bobot'] / 100);
    $rounded_group_nilai = round($group_nilai, 2);
    echo "$kat => Rata: $avg_score, Bobot: {$group['total_bobot']}%, NILAI: $rounded_group_nilai\n";
}

echo "\nREKAPITULASI (AMALIYA):\n";
$_GET['periode_id'] = $periode_id;
ob_start();
define('REKAP_INCLUDED', true);
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/cetak_rekap_keseluruhan.php';
$output = ob_get_clean();
preg_match('/AMALIYA MUFIDAH.*?<\/tr>/s', $output, $m1);
echo strip_tags($m1[0]);
?>
