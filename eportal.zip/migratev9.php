<?php
/**
 * Migration V9
 * - Memperbaiki Unique Key pada perf_siswa_guru agar menyertakan periode_id
 * - Menambahkan kolom target_dinilai pada perf_instrumen
 * - Membuat tabel perf_jenis_penilai
 */
require_once __DIR__ . '/api/config.php';

try {
    $pdo = db();
    
    echo "<h2>Migrasi V9: Perbaikan Unique Key E-Performance (Data Siswa) & Schema Pertanyaan</h2>";
    echo "<ul>";
    
    // Drop old unique key if exists
    try {
        $pdo->exec("ALTER TABLE `perf_siswa_guru` DROP INDEX `uk_siswa_guru`");
        echo "<li>[OK] Berhasil menghapus unique key lama <code>uk_siswa_guru</code>.</li>";
    } catch (PDOException $e) {
        echo "<li>[INFO] Unique key <code>uk_siswa_guru</code> mungkin tidak ditemukan atau sudah dihapus.</li>";
    }
    
    // Add new unique key
    try {
        $pdo->exec("ALTER TABLE `perf_siswa_guru` ADD UNIQUE KEY `uk_periode_siswa_guru` (`periode_id`, `perf_siswa_id`, `perf_ptk_id`)");
        echo "<li>[OK] Berhasil menambahkan unique key baru <code>uk_periode_siswa_guru</code>.</li>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate key') !== false) {
            echo "<li>[INFO] Unique key <code>uk_periode_siswa_guru</code> sudah ada.</li>";
        } else {
            echo "<li>[ERR] Gagal menambahkan unique key baru: " . htmlspecialchars($e->getMessage()) . "</li>";
        }
    }

    // Add target_dinilai to perf_instrumen
    try {
        $pdo->exec("ALTER TABLE `perf_instrumen` ADD COLUMN `target_dinilai` VARCHAR(255) NOT NULL DEFAULT 'Semua' AFTER `target_jabatan`");
        echo "<li>[OK] Berhasil menambahkan kolom <code>target_dinilai</code> ke tabel <code>perf_instrumen</code>.</li>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
            echo "<li>[INFO] Kolom <code>target_dinilai</code> sudah ada pada <code>perf_instrumen</code>.</li>";
        } else {
            echo "<li>[ERR] Gagal menambahkan kolom target_dinilai: " . htmlspecialchars($e->getMessage()) . "</li>";
        }
    }

    // Create perf_jenis_penilai
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `perf_jenis_penilai` (
            `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `periode_id` INT(11) UNSIGNED NOT NULL,
            `jenis_penilai` VARCHAR(100) NOT NULL,
            `target_dinilai` VARCHAR(255) NOT NULL DEFAULT 'Semua PTK',
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_periode` (`periode_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "<li>[OK] Berhasil memeriksa/membuat tabel <code>perf_jenis_penilai</code>.</li>";
    } catch (PDOException $e) {
        echo "<li>[ERR] Gagal membuat tabel perf_jenis_penilai: " . htmlspecialchars($e->getMessage()) . "</li>";
    }

    // Add target_dinilai to perf_jenis_penilai if exists but without column
    try {
        $pdo->exec("ALTER TABLE `perf_jenis_penilai` ADD COLUMN `target_dinilai` VARCHAR(255) NOT NULL DEFAULT 'Semua PTK' AFTER `jenis_penilai`");
        echo "<li>[OK] Berhasil menambahkan kolom <code>target_dinilai</code> ke tabel <code>perf_jenis_penilai</code>.</li>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
            // echo "<li>[INFO] Kolom target_dinilai sudah ada pada perf_jenis_penilai.</li>";
        } else {
            // Ignore error if table didn't exist prior to the previous query and was just created WITH the column
        }
    }
    
    echo "</ul>";
    echo "<p><b>Migrasi V9 Selesai!</b></p>";
    echo "<br><a href='index.php'>Kembali ke E-Portal</a>";
    
} catch (Exception $e) {
    echo "<h3>Error Koneksi Database:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
