<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT id, kategori, bobot FROM perf_instrumen WHERE is_manual=1");
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($res);
?>
