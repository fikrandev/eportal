<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT id, nama FROM perf_ptk WHERE nama LIKE '%ACHMAD RIZKI%'");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
