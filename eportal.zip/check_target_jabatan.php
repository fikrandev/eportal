<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT DISTINCT target_jabatan FROM perf_instrumen");
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($res);
?>
