<?php
/**
 * Migration v5 - E-Sarpras Room Types Reference
 */
require_once __DIR__ . '/api/config.php';

$pdo = db();

echo "<h3>Migration V5 - E-Sarpras</h3><pre>";

// Pastikan tabel sarpras_referensi ada
$queries = [
    "CREATE TABLE IF NOT EXISTS `sarpras_referensi` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `kategori` varchar(50) NOT NULL,
      `kode` varchar(50) DEFAULT NULL,
      `nama` varchar(100) NOT NULL,
      `keterangan` text DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;"
];

foreach ($queries as $sql) {
    try {
        $pdo->exec($sql);
        echo "[OK] Table sarpras_referensi structure verified.\n";
    } catch (Exception $e) {
        echo "[ERR] " . $e->getMessage() . "\n";
    }
}

// Inisialisasi Data Default Tipe Ruangan
$defaults = [
    'Ruang Kelas', 
    'Perpustakaan', 
    'Laboratorium', 
    'Ruang Guru', 
    'Ruang Kepsek', 
    'Ruang Tata Usaha', 
    'Gudang', 
    'Kamar Mandi/WC', 
    'Fasilitas Olahraga', 
    'Lainnya'
];

foreach ($defaults as $d) {
    try {
        $exists = $pdo->prepare("SELECT COUNT(*) FROM sarpras_referensi WHERE kategori='jenis_ruang' AND nama=?");
        $exists->execute([$d]);
        if ($exists->fetchColumn() == 0) {
            $pdo->prepare("INSERT INTO sarpras_referensi (kategori, nama) VALUES ('jenis_ruang', ?)")->execute([$d]);
            echo "[OK] Inserted room type: $d\n";
        } else {
            echo "[SKIP] Room type already exists: $d\n";
        }
    } catch (Exception $e) {
        echo "[ERR] Failed to insert $d: " . $e->getMessage() . "\n";
    }
}

echo "\nMigration Complete.";
echo "</pre>";
