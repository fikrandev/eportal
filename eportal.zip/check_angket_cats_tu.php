<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT i.kategori, COUNT(*) as cnt FROM perf_penilaian p JOIN perf_ptk pt ON p.dinilai_ptk_id = pt.id JOIN perf_instrumen i ON p.instrumen_id = i.id WHERE pt.jenis_ptk = 'Kepala TU' GROUP BY i.kategori");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
