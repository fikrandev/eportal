<?php
function db() {
    global $db_conn;
    if (!$db_conn) {
        $db_conn = new PDO('mysql:host=localhost;dbname=eportal', 'root', '');
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $db_conn;
}
$db = db();
$_GET['periode_id'] = 6;
ob_start();
define('REKAP_INCLUDED', true);
function perf_auth_check() { return ['role' => 'admin']; }
function get_setting() { return ''; }
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/cetak_rekap_keseluruhan.php';
$output = ob_get_clean();

preg_match('/AMALIYA MUFIDAH.*?<\/tr>/s', $output, $m1);
echo "Amaliya:\n"; print_r(strip_tags($m1[0]));

preg_match('/SOEDJOKO.*?<\/tr>/s', $output, $m2);
echo "\nSoedjoko:\n"; print_r(strip_tags($m2[0]));

preg_match('/ABDUL AZIZI.*?<\/tr>/s', $output, $m3);
echo "\nAzizi:\n"; print_r(strip_tags($m3[0]));
?>
