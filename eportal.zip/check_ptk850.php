<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$ptk_id = 850;
$periode_id = 6;

echo "Expected Evaluators for PTK 850:\n";
// Siswa
$stmtS = $db->query("SELECT perf_siswa_id FROM perf_siswa_guru WHERE perf_ptk_id = $ptk_id AND periode_id = $periode_id");
$siswa_ids = $stmtS->fetchAll(PDO::FETCH_COLUMN);
echo "Siswa: " . count($siswa_ids) . "\n";

// Kepsek
$stmtK = $db->query("SELECT id FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
$kepsek_ids = $stmtK->fetchAll(PDO::FETCH_COLUMN);
echo "Kepsek: " . count($kepsek_ids) . "\n";

// Sejawat
$stmtP = $db->query("SELECT penilai_ptk_id FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = $ptk_id AND periode_id = $periode_id");
$peer_ids = $stmtP->fetchAll(PDO::FETCH_COLUMN);
echo "Sejawat: " . count($peer_ids) . "\n";

echo "Actual Evaluators for PTK 850 in perf_penilaian:\n";
$stmtA = $db->query("SELECT DISTINCT penilai_id, penilai_type FROM perf_penilaian WHERE dinilai_ptk_id = $ptk_id AND periode_id = $periode_id");
$actuals = $stmtA->fetchAll(PDO::FETCH_ASSOC);
foreach($actuals as $a) {
    if($a['penilai_type'] == 'siswa') {
        $siswa_ids = array_diff($siswa_ids, [$a['penilai_id']]);
    }
}
echo "Siswa that did NOT evaluate:\n";
print_r($siswa_ids);
?>
