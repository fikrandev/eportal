<?php
/**
 * E-Portal Master Database Migration Script
 * Consolidates all system requirements: Core, E-Schedule, E-Sarpras, and E-Graduation
 * Idempotent: Can be run multiple times safely
 */

require_once __DIR__ . '/api/config.php';

echo "<h2>E-Portal Master Migration</h2>";
echo "<pre style='background:#1e293b; color:#fbbf24; padding:20px; border-radius:8px; overflow:auto;'>";

$pdo = db();

/**
 * Helper to add columns safely (Idempotent)
 */
function addColumn($table, $column, $definition) {
    global $pdo;
    try {
        $check = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'")->fetch();
        if (!$check) {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN $column $definition");
            echo "[OK] Added column `$column` to `$table`\n";
        } else {
            echo "[SKIP] Column `$column` already exists in `$table`\n";
        }
    } catch (Exception $e) {
        echo "[ERR] Failed to add column `$column` to `$table`: " . $e->getMessage() . "\n";
    }
}

// ---------------------------------------------------------
// 1. CORE SYSTEM TABLES
// ---------------------------------------------------------
echo "<h3>1. Initializing Core System...</h3>";
$coreTables = [
    "users" => "CREATE TABLE IF NOT EXISTS `users` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `username` VARCHAR(50) NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `nama_lengkap` VARCHAR(100) NOT NULL,
        `role` ENUM('superadmin','user','guru') NOT NULL DEFAULT 'user',
        `tempat_lahir` VARCHAR(100) DEFAULT NULL,
        `tgl_lahir` DATE DEFAULT NULL,
        `tupoksi` VARCHAR(150) DEFAULT NULL,
        `jabatan` VARCHAR(150) DEFAULT NULL,
        `mapel` VARCHAR(150) DEFAULT NULL,
        `status_guru` VARCHAR(100) DEFAULT NULL,
        `tpg` ENUM('Ya','Tidak') NOT NULL DEFAULT 'Tidak',
        `tmt` DATE DEFAULT NULL,
        `avatar` VARCHAR(255) DEFAULT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
        `last_login` DATETIME DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "modules" => "CREATE TABLE IF NOT EXISTS `modules` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `nama_modul` VARCHAR(100) NOT NULL,
        `slug` VARCHAR(100) NOT NULL,
        `deskripsi` TEXT DEFAULT NULL,
        `icon_svg` TEXT NOT NULL,
        `url_path` VARCHAR(255) NOT NULL,
        `color` VARCHAR(20) DEFAULT '#1565C0',
        `urutan` INT(11) NOT NULL DEFAULT 0,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_slug` (`slug`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "settings" => "CREATE TABLE IF NOT EXISTS `settings` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `setting_key` VARCHAR(100) NOT NULL,
        `setting_value` TEXT DEFAULT NULL,
        `setting_type` ENUM('text','number','boolean','json','file') NOT NULL DEFAULT 'text',
        `keterangan` VARCHAR(255) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_setting_key` (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "sessions" => "CREATE TABLE IF NOT EXISTS `sessions` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT(11) UNSIGNED NOT NULL,
        `token` VARCHAR(255) NOT NULL,
        `ip_address` VARCHAR(45) DEFAULT NULL,
        `user_agent` TEXT DEFAULT NULL,
        `expired_at` DATETIME NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_token` (`token`),
        CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "academic_years" => "CREATE TABLE IF NOT EXISTS `academic_years` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `tahun_ajaran` VARCHAR(9) NOT NULL,
        `semester` ENUM('1','2') NOT NULL DEFAULT '1',
        `tanggal_mulai` DATE DEFAULT NULL,
        `tanggal_selesai` DATE DEFAULT NULL,
        `is_active` TINYINT(1) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_academic_year_semester` (`tahun_ajaran`, `semester`),
        KEY `idx_active` (`is_active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "students" => "CREATE TABLE IF NOT EXISTS `students` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `no_urut` INT(11) DEFAULT 0,
        `nis` VARCHAR(50) NOT NULL,
        `nisn` VARCHAR(50) DEFAULT NULL,
        `nama` VARCHAR(150) NOT NULL,
        `tempat_lahir` VARCHAR(100) DEFAULT NULL,
        `jenis_kelamin` ENUM('L','P') NOT NULL,
        `tanggal_lahir` DATE NOT NULL,
        `kelas` VARCHAR(50) NOT NULL,
        `foto_path` VARCHAR(255) DEFAULT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_student_nis_year` (`academic_year_id`, `nis`),
        UNIQUE KEY `uk_student_nisn_year` (`academic_year_id`, `nisn`),
        KEY `idx_student_class` (`kelas`),
        CONSTRAINT `fk_students_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($coreTables as $name => $sql) {
    try { $pdo->exec($sql); echo "[OK] Core Table `$name` ensured.\n"; } catch (Exception $e) { echo "[ERR] Core Table `$name` failed: " . $e->getMessage() . "\n"; }
}

upsert_setting('nama_sekolah', get_setting('nama_sekolah', 'E-Portal Sekolah'), 'text', 'Nama sekolah yang ditampilkan');
upsert_setting('icon_sekolah', get_setting('icon_sekolah', ''), 'file', 'Path icon/logo sekolah');
upsert_setting('kepala_sekolah', get_setting('kepala_sekolah', get_setting('sarpras_kepala_sekolah', '')), 'text', 'Nama kepala sekolah untuk surat');
upsert_setting('kop_surat', get_setting('kop_surat', ''), 'file', 'Path kop surat global untuk semua modul');

try {
    $countYears = (int) $pdo->query("SELECT COUNT(*) FROM academic_years")->fetchColumn();
    if ($countYears === 0) {
        $year = ((int) date('n') >= 7) ? (int) date('Y') : (int) date('Y') - 1;
        $label = $year . '/' . ($year + 1);
        $stmt = $pdo->prepare("INSERT INTO academic_years (tahun_ajaran, semester, is_active) VALUES (?, '1', 1)");
        $stmt->execute([$label]);
        $activeId = $pdo->lastInsertId();
        upsert_setting('tahun_ajaran_aktif', $label, 'text', 'Tahun ajaran aktif global');
        upsert_setting('semester_aktif', '1', 'text', 'Semester aktif global');
        upsert_setting('academic_year_id_aktif', (string) $activeId, 'number', 'ID tahun ajaran aktif global');
        echo "[OK] Default academic year `$label` created.\n";
    }
} catch (Exception $e) {
    echo "[ERR] Default academic year seed failed: " . $e->getMessage() . "\n";
}

try {
    $graduationIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10.5 12 5 2 10.5 12 16l10-5.5Z"/><path d="M6 13v4c2 1.5 10 1.5 12 0v-4"/><path d="M12 16v5"/><path d="M8 21h8"/></svg>';
    $stmt = $pdo->prepare("
        INSERT INTO modules (nama_modul, slug, deskripsi, icon_svg, url_path, color, urutan, status)
        VALUES ('E-Graduation', 'e-graduation', 'Manajemen kelulusan dan nilai akhir siswa', ?, 'modules/e-graduation/', '#0F766E', 4, 1)
        ON DUPLICATE KEY UPDATE
            nama_modul = VALUES(nama_modul),
            deskripsi = VALUES(deskripsi),
            icon_svg = VALUES(icon_svg),
            url_path = VALUES(url_path),
            color = VALUES(color),
            status = VALUES(status)
    ");
    $stmt->execute([$graduationIcon]);
    echo "[OK] Module `E-Graduation` ensured.\n";
} catch (Exception $e) {
    echo "[ERR] Module `E-Graduation` seed failed: " . $e->getMessage() . "\n";
}

// ---------------------------------------------------------
// 2. E-SCHEDULE MODULE TABLES
// ---------------------------------------------------------
echo "<h3>2. Initializing E-Schedule Module...</h3>";
$schTables = [
    "sch_jam_belajar" => "CREATE TABLE IF NOT EXISTS `sch_jam_belajar` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `hari` VARCHAR(20) NOT NULL,
        `jam_ke` INT(11) NOT NULL,
        `tipe` ENUM('Pembelajaran', 'Istirahat', 'Upacara', 'Pembiasaan') NOT NULL DEFAULT 'Pembelajaran',
        `nama_jam` VARCHAR(50) NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_hari_jam` (`hari`, `jam_ke`)
    )",
    "sch_mapel" => "CREATE TABLE IF NOT EXISTS `sch_mapel` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `kode_mapel` VARCHAR(50) NOT NULL,
        `nama_mapel` VARCHAR(150) NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode_mapel` (`kode_mapel`)
    )",
    "sch_kelas" => "CREATE TABLE IF NOT EXISTS `sch_kelas` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `rombel` INT(11) NOT NULL,
        `nama_kelas` VARCHAR(100) NOT NULL,
        PRIMARY KEY (`id`)
    )",
    "sch_guru" => "CREATE TABLE IF NOT EXISTS `sch_guru` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `kode_guru` VARCHAR(50) NOT NULL,
        `nama_guru` VARCHAR(150) NOT NULL,
        PRIMARY KEY (`id`)
    )",
    "sch_distribusi" => "CREATE TABLE IF NOT EXISTS `sch_distribusi` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `guru_id` INT(11) UNSIGNED NOT NULL,
        `kelas_id` INT(11) UNSIGNED NOT NULL,
        `mapel_id` INT(11) UNSIGNED NOT NULL,
        `jp` INT NOT NULL,
        PRIMARY KEY (`id`)
    )",
    "sch_jadwal" => "CREATE TABLE IF NOT EXISTS `sch_jadwal` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `kelas_id` INT(11) UNSIGNED NOT NULL,
        `jam_belajar_id` INT(11) UNSIGNED NOT NULL,
        `distribusi_id` INT(11) UNSIGNED NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kelas_jam` (`kelas_id`, `jam_belajar_id`)
    )"
];

foreach ($schTables as $name => $sql) {
    try { $pdo->exec($sql); echo "[OK] Schedule Table `$name` ensured.\n"; } catch (Exception $e) { echo "[ERR] Schedule Table `$name` failed: " . $e->getMessage() . "\n"; }
}

// ---------------------------------------------------------
// 3. E-GRADUATION MODULE TABLES
// ---------------------------------------------------------
echo "<h3>3. Initializing E-Graduation Module...</h3>";
$gradTables = [
    "grad_subject_groups" => "CREATE TABLE IF NOT EXISTS `grad_subject_groups` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `kode` VARCHAR(20) NOT NULL,
        `nama` VARCHAR(150) NOT NULL,
        `tipe` ENUM('wajib','pilihan','lainnya') NOT NULL DEFAULT 'wajib',
        `deskripsi` TEXT DEFAULT NULL,
        `urutan` INT(11) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_group_year_code` (`academic_year_id`, `kode`),
        KEY `idx_grad_group_year` (`academic_year_id`),
        CONSTRAINT `fk_grad_group_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_subjects" => "CREATE TABLE IF NOT EXISTS `grad_subjects` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `group_id` INT(11) UNSIGNED NOT NULL,
        `kode_mapel` VARCHAR(50) DEFAULT NULL,
        `nama_mapel` VARCHAR(150) NOT NULL,
        `kelas` VARCHAR(100) DEFAULT NULL,
        `urutan` INT(11) NOT NULL DEFAULT 0,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_subject_scope` (`academic_year_id`, `group_id`, `kelas`, `nama_mapel`),
        KEY `idx_grad_subject_year` (`academic_year_id`),
        KEY `idx_grad_subject_group` (`group_id`),
        KEY `idx_grad_subject_class` (`kelas`),
        CONSTRAINT `fk_grad_subject_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
        CONSTRAINT `fk_grad_subject_group` FOREIGN KEY (`group_id`) REFERENCES `grad_subject_groups`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_letter_settings" => "CREATE TABLE IF NOT EXISTS `grad_letter_settings` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `start_number` INT(11) NOT NULL DEFAULT 1,
        `total` INT(11) NOT NULL DEFAULT 0,
        `letter_format` VARCHAR(255) NOT NULL,
        `graduation_date` DATE DEFAULT NULL,
        `signing_date` DATE DEFAULT NULL,
        `headmaster_user_id` INT(11) UNSIGNED DEFAULT NULL,
        `headmaster_name` VARCHAR(150) DEFAULT NULL,
        `headmaster_niy` VARCHAR(50) DEFAULT NULL,
        `headmaster_position` VARCHAR(100) NOT NULL DEFAULT 'Kepala Sekolah',
        `kop_image` VARCHAR(255) DEFAULT NULL,
        `decision_number` VARCHAR(100) DEFAULT NULL,
        `decision_date` DATE DEFAULT NULL,
        `decision_about` VARCHAR(255) DEFAULT NULL,
        `skl_city` VARCHAR(100) DEFAULT NULL,
        `announcement_status` VARCHAR(20) NOT NULL DEFAULT 'not_set',
        `announcement_at` DATETIME DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_letter_year` (`academic_year_id`),
        KEY `idx_grad_letter_headmaster` (`headmaster_user_id`),
        CONSTRAINT `fk_grad_letter_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
        CONSTRAINT `fk_grad_letter_headmaster` FOREIGN KEY (`headmaster_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_student_letters" => "CREATE TABLE IF NOT EXISTS `grad_student_letters` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `student_id` INT(11) UNSIGNED NOT NULL,
        `sequence_no` INT(11) NOT NULL,
        `letter_number` VARCHAR(255) NOT NULL,
        `graduation_date` DATE DEFAULT NULL,
        `signing_date` DATE DEFAULT NULL,
        `headmaster_name` VARCHAR(150) DEFAULT NULL,
        `headmaster_niy` VARCHAR(50) DEFAULT NULL,
        `headmaster_position` VARCHAR(100) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_student_letter` (`academic_year_id`, `student_id`),
        UNIQUE KEY `uk_grad_sequence_letter` (`academic_year_id`, `sequence_no`),
        KEY `idx_grad_student_letter_year` (`academic_year_id`),
        CONSTRAINT `fk_grad_student_letter_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
        CONSTRAINT `fk_grad_student_letter_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_student_scores" => "CREATE TABLE IF NOT EXISTS `grad_student_scores` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `student_id` INT(11) UNSIGNED NOT NULL,
        `subject_id` INT(11) UNSIGNED NOT NULL,
        `nilai_akhir` DECIMAL(5,2) DEFAULT NULL,
        `predikat` VARCHAR(10) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_score_student_subject` (`academic_year_id`, `student_id`, `subject_id`),
        KEY `idx_grad_score_year` (`academic_year_id`),
        KEY `idx_grad_score_subject` (`subject_id`),
        CONSTRAINT `fk_grad_score_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
        CONSTRAINT `fk_grad_score_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
        CONSTRAINT `fk_grad_score_subject` FOREIGN KEY (`subject_id`) REFERENCES `grad_subjects`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_teacher_access" => "CREATE TABLE IF NOT EXISTS `grad_teacher_access` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT(11) UNSIGNED NOT NULL,
        `access_role` ENUM('wali_kelas') NOT NULL DEFAULT 'wali_kelas',
        `kelas` VARCHAR(100) NOT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_access_user` (`user_id`),
        KEY `idx_grad_access_class` (`kelas`),
        CONSTRAINT `fk_grad_access_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_student_accounts" => "CREATE TABLE IF NOT EXISTS `grad_student_accounts` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `student_id` INT(11) UNSIGNED NOT NULL,
        `username` VARCHAR(50) NOT NULL,
        `password_hash` VARCHAR(255) NOT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `generated_at` DATETIME DEFAULT NULL,
        `last_login` DATETIME DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_student_account` (`academic_year_id`, `student_id`),
        UNIQUE KEY `uk_grad_student_username` (`academic_year_id`, `username`),
        KEY `idx_grad_student_account_year` (`academic_year_id`),
        CONSTRAINT `fk_grad_student_account_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
        CONSTRAINT `fk_grad_student_account_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "grad_student_sessions" => "CREATE TABLE IF NOT EXISTS `grad_student_sessions` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `account_id` INT(11) UNSIGNED NOT NULL,
        `token` VARCHAR(100) NOT NULL,
        `ip_address` VARCHAR(45) DEFAULT NULL,
        `user_agent` TEXT DEFAULT NULL,
        `expired_at` DATETIME NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_grad_student_session_token` (`token`),
        KEY `idx_grad_student_session_account` (`account_id`),
        CONSTRAINT `fk_grad_student_session_account` FOREIGN KEY (`account_id`) REFERENCES `grad_student_accounts`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($gradTables as $name => $sql) {
    try { $pdo->exec($sql); echo "[OK] Graduation Table `$name` ensured.\n"; } catch (Exception $e) { echo "[ERR] Graduation Table `$name` failed: " . $e->getMessage() . "\n"; }
}

addColumn('grad_letter_settings', 'kop_image', "VARCHAR(255) DEFAULT NULL AFTER headmaster_position");
addColumn('grad_letter_settings', 'decision_number', "VARCHAR(100) DEFAULT NULL AFTER kop_image");
addColumn('grad_letter_settings', 'decision_date', "DATE DEFAULT NULL AFTER decision_number");
addColumn('grad_letter_settings', 'decision_about', "VARCHAR(255) DEFAULT NULL AFTER decision_date");
addColumn('grad_letter_settings', 'skl_city', "VARCHAR(100) DEFAULT NULL AFTER decision_about");
addColumn('grad_letter_settings', 'announcement_status', "VARCHAR(20) NOT NULL DEFAULT 'not_set' AFTER skl_city");
addColumn('grad_letter_settings', 'announcement_at', "DATETIME DEFAULT NULL AFTER announcement_status");

// ---------------------------------------------------------
// 4. E-SARPRAS MODULE TABLES (Consolidated)
// ---------------------------------------------------------
echo "<h3>4. Initializing E-Sarpras Module...</h3>";
$spTables = [
    "kategori_sarpras" => "CREATE TABLE IF NOT EXISTS `kategori_sarpras` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `nama` VARCHAR(100) NOT NULL,
        `kode` VARCHAR(10) NOT NULL,
        `jenis` ENUM('sarana', 'prasarana') NOT NULL DEFAULT 'sarana',
        `keterangan` TEXT DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode` (`kode`)
    )",
    "tanah" => "CREATE TABLE IF NOT EXISTS `tanah` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `nama` VARCHAR(150) NOT NULL,
        `kode_tanah` VARCHAR(50) DEFAULT NULL,
        `lokasi` TEXT DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
        `no_sertifikat` VARCHAR(100) DEFAULT NULL,
        `kepemilikan` VARCHAR(50) DEFAULT 'Milik Sendiri',
        PRIMARY KEY (`id`)
    )",
    "bangunan" => "CREATE TABLE IF NOT EXISTS `bangunan` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `tanah_id` INT(11) UNSIGNED NOT NULL,
        `nama` VARCHAR(150) NOT NULL,
        `kode_bangunan` VARCHAR(50) DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        CONSTRAINT `fk_b_t` FOREIGN KEY (`tanah_id`) REFERENCES `tanah`(`id`) ON DELETE CASCADE
    )",
    "ruang" => "CREATE TABLE IF NOT EXISTS `ruang` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `bangunan_id` INT(11) UNSIGNED NOT NULL,
        `pj_id` INT(11) UNSIGNED DEFAULT NULL,
        `nama` VARCHAR(100) NOT NULL,
        `kode_ruang` VARCHAR(20) NOT NULL,
        `panjang_m` DECIMAL(10,2) DEFAULT NULL,
        `lebar_m` DECIMAL(10,2) DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) DEFAULT NULL,
        `kapasitas` INT(11) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode_ruang` (`kode_ruang`),
        CONSTRAINT `fk_r_b` FOREIGN KEY (`bangunan_id`) REFERENCES `bangunan`(`id`) ON DELETE CASCADE
    )",
    "sarpras" => "CREATE TABLE IF NOT EXISTS `sarpras` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `ruang_id` INT(11) UNSIGNED NOT NULL,
        `kategori_id` INT(11) UNSIGNED NOT NULL,
        `nama` VARCHAR(200) NOT NULL,
        `kode_inventaris` VARCHAR(50) NOT NULL,
        `merk` VARCHAR(100) DEFAULT NULL,
        `spesifikasi` TEXT DEFAULT NULL,
        `satuan` VARCHAR(50) DEFAULT 'Unit',
        `jumlah` INT(11) NOT NULL DEFAULT 1,
        `harga_perolehan` DECIMAL(15,2) NOT NULL DEFAULT 0,
        `tahun_perolehan` YEAR NOT NULL,
        `sumber_dana` VARCHAR(50) DEFAULT 'BOS',
        `kondisi_baik` INT(11) NOT NULL DEFAULT 0,
        `kondisi_rusak_ringan` INT(11) NOT NULL DEFAULT 0,
        `kondisi_rusak_berat` INT(11) NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode_inv` (`kode_inventaris`),
        CONSTRAINT `fk_s_r` FOREIGN KEY (`ruang_id`) REFERENCES `ruang`(`id`) ON DELETE CASCADE
    )",
    "sarpras_pj" => "CREATE TABLE IF NOT EXISTS `sarpras_pj` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `bangunan_id` INT(11) UNSIGNED NOT NULL,
        `user_id` INT NULL,
        `nama` VARCHAR(150) NOT NULL,
        `nip` VARCHAR(50),
        `jabatan` VARCHAR(100),
        `keterangan` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        CONSTRAINT `fk_pj_bang` FOREIGN KEY (`bangunan_id`) REFERENCES `bangunan`(`id`) ON DELETE CASCADE
    )",
    "sarpras_peminjaman" => "CREATE TABLE IF NOT EXISTS `sarpras_peminjaman` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT NULL,
        `nama_peminjam` VARCHAR(255) NOT NULL,
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `jumlah` INT DEFAULT 1,
        `tanggal_pinjam` DATE NOT NULL,
        `status` ENUM('Dipinjam', 'Dikembalikan') DEFAULT 'Dipinjam',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        CONSTRAINT `fk_pinjam_s` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
    )",
    "sarpras_roles_def" => "CREATE TABLE IF NOT EXISTS `sarpras_roles_def` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `nama` VARCHAR(100) NOT NULL,
        `deskripsi` TEXT,
        `is_locked` TINYINT(1) DEFAULT 0
    )",
    "sarpras_role_permissions" => "CREATE TABLE IF NOT EXISTS `sarpras_role_permissions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `role_id` INT NOT NULL,
        `permission_key` VARCHAR(100) NOT NULL,
        UNIQUE KEY `uk_rp` (`role_id`, `permission_key`)
    )",
    "sarpras_roles" => "CREATE TABLE IF NOT EXISTS `sarpras_roles` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `custom_role_id` INT NULL,
        `role` VARCHAR(50),
        UNIQUE KEY `uk_u` (`user_id`)
    )",
    "sarpras_referensi" => "CREATE TABLE IF NOT EXISTS `sarpras_referensi` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `kategori` VARCHAR(50) NOT NULL,
        `kode` VARCHAR(50) DEFAULT NULL,
        `nama` VARCHAR(100) NOT NULL,
        `keterangan` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_kategori` (`kategori`)
    )",
    "sarpras_perbaikan" => "CREATE TABLE IF NOT EXISTS `sarpras_perbaikan` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `berita_acara_id` INT NULL,
        `tanggal` DATE,
        `status` ENUM('Diajukan', 'Proses', 'Selesai', 'Batal') DEFAULT 'Diajukan',
        CONSTRAINT `fk_perb_sar` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
    )",
    "sequence_tracker" => "CREATE TABLE IF NOT EXISTS `sequence_tracker` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `kategori_kode` VARCHAR(10),
        `tahun` YEAR,
        `last_seq` INT DEFAULT 0,
        UNIQUE KEY `uk_st` (`kategori_kode`, `tahun`)
    )"
];

foreach ($spTables as $name => $sql) {
    try { $pdo->exec($sql); echo "[OK] Sarpras Table `$name` ensured.\n"; } catch (Exception $e) { echo "[ERR] Sarpras Table `$name` failed: " . $e->getMessage() . "\n"; }
}

// ---------------------------------------------------------
// 5. E-XAM CARD MODULE TABLES
// ---------------------------------------------------------
echo "<h3>5. Initializing E-Xam Card Module...</h3>";
$xamTables = [
    "xam_exams" => "CREATE TABLE IF NOT EXISTS `xam_exams` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `exam_name` VARCHAR(150) NOT NULL,
        `exam_start_date` DATE NOT NULL,
        `exam_end_date` DATE NOT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_xam_exam_year` (`academic_year_id`),
        CONSTRAINT `fk_xam_exam_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "xam_exam_settings" => "CREATE TABLE IF NOT EXISTS `xam_exam_settings` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `letter_manual_no` VARCHAR(30) DEFAULT NULL,
        `letter_code` VARCHAR(120) NOT NULL DEFAULT 'I04.1/SMA.WH1',
        `letter_date` DATE DEFAULT NULL,
        `sign_date` DATE DEFAULT NULL,
        `headmaster_user_id` INT(11) UNSIGNED DEFAULT NULL,
        `headmaster_name` VARCHAR(150) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_setting_exam` (`exam_id`),
        KEY `idx_xam_headmaster` (`headmaster_user_id`),
        CONSTRAINT `fk_xam_setting_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
        CONSTRAINT `fk_xam_setting_headmaster` FOREIGN KEY (`headmaster_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "xam_exam_classes" => "CREATE TABLE IF NOT EXISTS `xam_exam_classes` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `kelas` VARCHAR(50) NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_exam_class` (`exam_id`, `kelas`),
        KEY `idx_xam_exam_class_exam` (`exam_id`),
        CONSTRAINT `fk_xam_exam_class_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    "xam_exam_students" => "CREATE TABLE IF NOT EXISTS `xam_exam_students` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `student_id` INT(11) UNSIGNED NOT NULL,
        `ruang_ujian` VARCHAR(100) DEFAULT NULL,
        `username` VARCHAR(60) NOT NULL,
        `password_hash` VARCHAR(255) DEFAULT NULL,
        `password_plain` VARCHAR(80) DEFAULT NULL,
        `status` ENUM('OKE','DITANGGUHKAN') NOT NULL DEFAULT 'DITANGGUHKAN',
        `suspension_note` VARCHAR(255) DEFAULT 'Silakan hubungi Wali Kelas / Waka. Kesiswaan',
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_exam_student` (`exam_id`, `student_id`),
        KEY `idx_xam_exam_student_exam` (`exam_id`),
        KEY `idx_xam_exam_student_status` (`status`),
        CONSTRAINT `fk_xam_exam_student_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
        CONSTRAINT `fk_xam_exam_student_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($xamTables as $name => $sql) {
    try { $pdo->exec($sql); echo "[OK] Xam Table `$name` ensured.\n"; } catch (Exception $e) { echo "[ERR] Xam Table `$name` failed: " . $e->getMessage() . "\n"; }
}

try {
    $xamIcon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10"/><path d="M7 12h10"/><path d="M7 16h6"/></svg>';
    $stmt = $pdo->prepare("
        INSERT INTO modules (nama_modul, slug, deskripsi, icon_svg, url_path, color, urutan, status)
        VALUES ('E-Xam Card', 'e-xam-card', 'Manajemen kartu ujian siswa', ?, 'modules/e-xam-card/', '#0F766E', 5, 1)
        ON DUPLICATE KEY UPDATE
            nama_modul = VALUES(nama_modul),
            deskripsi = VALUES(deskripsi),
            icon_svg = VALUES(icon_svg),
            url_path = VALUES(url_path),
            color = VALUES(color),
            status = VALUES(status)
    ");
    $stmt->execute([$xamIcon]);
    echo "[OK] Module `E-Xam Card` ensured.\n";
} catch (Exception $e) {
    echo "[ERR] Module `E-Xam Card` seed failed: " . $e->getMessage() . "\n";
}

// ---------------------------------------------------------
// 5. COLUMN EVOLUTIONS (Idempotent)
// ---------------------------------------------------------
echo "<h3>6. Applying Incremental Column Updates...</h3>";
addColumn('users', 'tempat_lahir', "VARCHAR(100) DEFAULT NULL AFTER nama_lengkap");
addColumn('users', 'tgl_lahir', "DATE DEFAULT NULL AFTER tempat_lahir");
addColumn('users', 'tupoksi', "VARCHAR(150) DEFAULT NULL AFTER tgl_lahir");
addColumn('users', 'jabatan', "VARCHAR(150) DEFAULT NULL AFTER tupoksi");
addColumn('users', 'mapel', "VARCHAR(150) DEFAULT NULL AFTER jabatan");
addColumn('users', 'status_guru', "VARCHAR(100) DEFAULT NULL AFTER mapel");
addColumn('users', 'tpg', "ENUM('Ya','Tidak') NOT NULL DEFAULT 'Tidak' AFTER status_guru");
addColumn('users', 'tmt', "DATE DEFAULT NULL AFTER tpg");
addColumn('students', 'tempat_lahir', "VARCHAR(100) DEFAULT NULL AFTER nama");

addColumn('sarpras', 'kepemilikan', "VARCHAR(50) DEFAULT 'Milik Sendiri' AFTER sumber_dana");
addColumn('sarpras', 'jenis_sarana', "VARCHAR(100) DEFAULT NULL AFTER kepemilikan");
addColumn('sarpras', 'no_polisi', "VARCHAR(20) DEFAULT NULL AFTER jenis_sarana");
addColumn('sarpras', 'no_bpkb', "VARCHAR(30) DEFAULT NULL AFTER no_polisi");
addColumn('sarpras', 'alamat', "TEXT DEFAULT NULL AFTER no_bpkb");
addColumn('sarpras', 'grup_pintasan', "VARCHAR(50) DEFAULT NULL");
addColumn('sarpras', 'bk_id', "INT NULL COMMENT 'Ref to Book Classification' AFTER kategori_id");

addColumn('sarpras_pj', 'user_id', "INT NULL AFTER nip");
addColumn('sarpras_pj', 'jabatan', "VARCHAR(100) AFTER nip");

addColumn('sarpras_roles', 'custom_role_id', "INT NULL AFTER user_id");
addColumn('sarpras_roles', 'updated_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

addColumn('ruang', 'pj_id', "INT(11) UNSIGNED NULL AFTER bangunan_id");

// Remove old text columns from ruang if they exist (migration process)
try {
    $c1 = $pdo->query("SHOW COLUMNS FROM ruang LIKE 'penanggung_jawab'")->fetch();
    if ($c1) { $pdo->exec("ALTER TABLE ruang DROP COLUMN penanggung_jawab"); echo "[OK] Dropped obsolete `penanggung_jawab` from `ruang`.\n"; }
    $c2 = $pdo->query("SHOW COLUMNS FROM ruang LIKE 'nip_penanggung_jawab'")->fetch();
    if ($c2) { $pdo->exec("ALTER TABLE ruang DROP COLUMN nip_penanggung_jawab"); echo "[OK] Dropped obsolete `nip_penanggung_jawab` from `ruang`.\n"; }
} catch (Exception $e) { echo "[SKIP] Cleanup of old ruang columns.\n"; }

try {
    $refs = [
        ['tupoksi', 'Guru Mata Pelajaran', 'Tugas pokok guru'],
        ['tupoksi', 'Wali Kelas', 'Tugas tambahan guru'],
        ['tupoksi', 'Pembina Ekstrakurikuler', 'Tugas tambahan guru'],
        ['jabatan', 'Guru', 'Jabatan guru'],
        ['jabatan', 'Wali Kelas', 'Jabatan/tugas guru'],
        ['jabatan', 'Kepala Sekolah', 'Jabatan struktural'],
        ['jabatan', 'Wakil Kepala Sekolah', 'Jabatan struktural'],
        ['status_guru', 'PNS', 'Status kepegawaian guru'],
        ['status_guru', 'PPPK', 'Status kepegawaian guru'],
        ['status_guru', 'GTY', 'Status kepegawaian guru'],
        ['status_guru', 'GTT', 'Status kepegawaian guru'],
        ['status_guru', 'Honorer', 'Status kepegawaian guru']
    ];
    $stmt = $pdo->prepare("INSERT INTO sarpras_referensi (kategori, nama, keterangan) SELECT ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM sarpras_referensi WHERE kategori=? AND nama=?)");
    foreach ($refs as $ref) {
        $stmt->execute([$ref[0], $ref[1], $ref[2], $ref[0], $ref[1]]);
    }
    echo "[OK] Guru reference defaults ensured.\n";
} catch (Exception $e) {
    echo "[ERR] Guru reference seed failed: " . $e->getMessage() . "\n";
}

// ---------------------------------------------------------
// 7. DATA CLEANUP — decode HTML entities in student names
// ---------------------------------------------------------
echo "<h3>7. Cleaning HTML Entities from Student Data...</h3>";
$entityFixes = [
    ['&#039;', "'"],
    ['&amp;', '&'],
    ['&quot;', '"'],
    ['&lt;', '<'],
    ['&gt;', '>'],
];
$cleanTables = [
    ['students', ['nama', 'tempat_lahir']],
    ['users', ['nama_lengkap']],
];
foreach ($cleanTables as [$table, $columns]) {
    foreach ($columns as $col) {
        foreach ($entityFixes as [$entity, $char]) {
            try {
                $count = $pdo->exec("UPDATE `$table` SET `$col` = REPLACE(`$col`, '$entity', '$char') WHERE `$col` LIKE '%$entity%'");
                if ($count > 0) {
                    echo "[OK] Fixed $count rows in `$table`.`$col`: '$entity' → '$char'\n";
                }
            } catch (Exception $e) {
                echo "[SKIP] `$table`.`$col`: " . $e->getMessage() . "\n";
            }
        }
    }
}
echo "[OK] Data cleanup completed.\n";

echo "<h3>--- MASTER MIGRATION COMPLETED ---</h3>";
echo "</pre>";
echo "<div style='margin-top:20px; font-family:sans-serif;'><a href='index.php' style='padding:10px 20px; background:#1e293b; color:white; border-radius:6px; text-decoration:none;'>Selesai! Buka Dashboard</a></div>";
