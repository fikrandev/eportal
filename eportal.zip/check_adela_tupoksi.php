<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT pt.nama, pt.jenis_ptk, u.tupoksi, u.jabatan FROM perf_ptk pt JOIN users u ON pt.niy COLLATE utf8mb4_unicode_ci = u.username WHERE pt.nama LIKE '%ADELA%' OR pt.nama LIKE '%NOFI%'");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
