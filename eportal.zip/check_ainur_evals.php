<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$ptk_id = 850;
$periode_id = 6;

$stmtS = $db->query("SELECT perf_siswa_id FROM perf_siswa_guru WHERE perf_ptk_id = $ptk_id AND periode_id = $periode_id");
$siswa_ids = $stmtS->fetchAll(PDO::FETCH_COLUMN);

echo "Siswa that evaluate AINUR:\n";
foreach($siswa_ids as $sid) {
    // Get total expected for this student
    $stmtSt = $db->query("SELECT perf_user_id, nama_siswa FROM perf_siswa WHERE id = $sid");
    $s = $stmtSt->fetch(PDO::FETCH_ASSOC);
    $p_id = $s['perf_user_id'];
    
    // targets
    $stmtTargets = $db->prepare("
        SELECT jenis_ptk, COUNT(id) as jml 
        FROM perf_ptk 
        WHERE status = 1 AND (
            jenis_ptk = 'tu' 
            OR id IN (SELECT perf_ptk_id FROM perf_siswa_guru WHERE perf_siswa_id = ?)
        )
        GROUP BY jenis_ptk
    ");
    $stmtTargets->execute([$sid]);
    $target_groups = $stmtTargets->fetchAll(PDO::FETCH_ASSOC);

    $stmtQ_dyn = $db->prepare("
        SELECT COUNT(id) FROM perf_instrumen WHERE periode_id = ? AND is_manual = 0 AND (
            (FIND_IN_SET('Siswa', target_jabatan) > 0 AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0))
            OR
            (FIND_IN_SET(?, target_jabatan) > 0 AND FIND_IN_SET('Siswa', target_dinilai) > 0)
        )
    ");

    $total_expected = 0;
    foreach ($target_groups as $tg) {
        $t_jenis = $tg['jenis_ptk'] ?: 'Guru';
        $stmtQ_dyn->execute([$periode_id, $t_jenis, $t_jenis]);
        $q_per_target = (int)$stmtQ_dyn->fetchColumn();
        $total_expected += ($q_per_target * $tg['jml']);
    }
    
    if ($total_expected === 0) $total_expected = 1;
    $stmtAns = $db->prepare("SELECT COUNT(*) FROM perf_penilaian WHERE penilai_id = ? AND periode_id = ?");
    $stmtAns->execute([$p_id, $periode_id]);
    $answered = (int)$stmtAns->fetchColumn();
    
    // Check if they specifically evaluated AINUR
    $stmtAnsA = $db->prepare("SELECT COUNT(*) FROM perf_penilaian WHERE penilai_id = ? AND periode_id = ? AND dinilai_ptk_id = ?");
    $stmtAnsA->execute([$p_id, $periode_id, $ptk_id]);
    $evaluated_ainur = (int)$stmtAnsA->fetchColumn();
    
    echo $s['nama_siswa'] . " - Total Perc: " . round(($answered / $total_expected) * 100) . "%, Eval Ainur: $evaluated_ainur\n";
}
?>
