<?php
require_once __DIR__ . '/api/config.php';

try {
    $db = db();
    echo "Starting Migration v12...<br>\n";

    // Add is_manual column to perf_instrumen
    $check_column = $db->query("SHOW COLUMNS FROM `perf_instrumen` LIKE 'is_manual'");
    if ($check_column->rowCount() == 0) {
        $db->exec("ALTER TABLE `perf_instrumen` ADD `is_manual` TINYINT(1) NOT NULL DEFAULT 0 AFTER `bobot`");
        echo "[OK] Added 'is_manual' column to 'perf_instrumen' table.<br>\n";
    } else {
        echo "[INFO] Column 'is_manual' already exists in 'perf_instrumen'.<br>\n";
    }

    echo "<b>Migration v12 completed successfully.</b><br>\n";
} catch (PDOException $e) {
    echo "<b>Migration failed:</b> " . $e->getMessage() . "<br>\n";
}
