<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
$ptk_id = 850;

$stmtS = $db->prepare("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = ? AND periode_id = ?");
$stmtS->execute([$ptk_id, $periode_id]);
$siswa_count = (int)$stmtS->fetchColumn();

$stmtK = $db->query("SELECT COUNT(id) FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
$total_kepsek = (int)$stmtK->fetchColumn();

$stmtPeer = $db->prepare("SELECT COUNT(*) FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = ? AND periode_id = ?");
$stmtPeer->execute([$ptk_id, $periode_id]);
$peer_count = (int)$stmtPeer->fetchColumn();

echo "Siswa: $siswa_count\n";
echo "Kepsek: $total_kepsek\n";
echo "Diri Sendiri: 1\n";
echo "Sejawat: $peer_count\n";
echo "Total Expected: " . ($siswa_count + $total_kepsek + 1 + $peer_count) . "\n";
?>
