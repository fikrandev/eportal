<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT DISTINCT kategori FROM perf_instrumen WHERE is_manual=1");
print_r($stmt->fetchAll(PDO::FETCH_COLUMN));
?>
