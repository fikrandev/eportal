<?php
require_once __DIR__ . '/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT DISTINCT penilai_type FROM perf_penilaian");
$res = $stmt->fetchAll(PDO::FETCH_COLUMN);
print_r($res);
?>
