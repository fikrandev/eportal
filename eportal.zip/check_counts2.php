<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
echo "Siswa guru (PTK=4) " . $db->query("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = 4 AND periode_id = 6")->fetchColumn() . "\n";
echo "Siswa guru (PTK=5 - Guru BK) " . $db->query("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = 5 AND periode_id = 6")->fetchColumn() . "\n";
?>
