<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
$stmtManualInst = $db->prepare("SELECT id, kategori, bobot, skor_ya, target_dinilai FROM perf_instrumen WHERE periode_id = ? AND is_manual = 1 ORDER BY urutan ASC, id ASC");
$stmtManualInst->execute([$periode_id]);
$allManualInst = $stmtManualInst->fetchAll(PDO::FETCH_ASSOC);

$main_manual = [];
$category_bobot = [];
foreach ($allManualInst as $inst) {
    if ((float)$inst['bobot'] > 0) {
        $kat = trim($inst['kategori']);
        if (!isset($main_manual[$kat])) {
            $main_manual[$kat] = [
                'kategori' => $kat,
                'bobot' => 0,
                'ids' => []
            ];
            $category_bobot[$kat] = 0;
        }
        $main_manual[$kat]['bobot'] += (float)$inst['bobot'];
        $main_manual[$kat]['ids'][] = $inst;
        $category_bobot[$kat] += (float)$inst['bobot'];
    }
}
$columns = [];
foreach ($main_manual as $kat => $m) {
    $columns[] = [
        'type' => 'manual',
        'key' => $kat,
        'bobot' => $category_bobot[$kat]
    ];
}
echo "COUNT COLUMNS: " . count($columns) . "\n";
print_r($columns);
?>
