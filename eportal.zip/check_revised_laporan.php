<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;

// Get active evaluator roles
$stmtR = $db->prepare("SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = ?");
$stmtR->execute([$periode_id]);
$active_roles = $stmtR->fetchAll(PDO::FETCH_COLUMN);

// Let's create a helper function that checks if a role targets a specific jenis_ptk
function role_targets_jenis_ptk($db, $periode_id, $role, $target_dinilai) {
    $rater_str = $role;
    $rater_fallback = (stripos($role, 'Guru') !== false || stripos($role, 'Wali Kelas') !== false) ? 'Guru' : $role;
    
    $stmt = $db->prepare("
        SELECT COUNT(id) FROM perf_instrumen WHERE periode_id = ? AND is_manual = 0 AND (
            (
                (FIND_IN_SET(?, target_jabatan) > 0 OR FIND_IN_SET(?, target_jabatan) > 0)
                AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0)
            )
            OR
            (
                FIND_IN_SET(?, target_jabatan) > 0 
                AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0 OR FIND_IN_SET(?, target_dinilai) > 0)
            )
            OR
            (FIND_IN_SET(?, target_jabatan) > 0 AND FIND_IN_SET(?, target_dinilai) > 0)
        )
    ");
    $stmt->execute([
        $periode_id, 
        $rater_str, $rater_fallback, $target_dinilai,
        $rater_str, $target_dinilai, $rater_str,
        $target_dinilai, $rater_str
    ]);
    return $stmt->fetchColumn() > 0;
}

$has_siswa = in_array('Siswa', $active_roles);
$has_kepsek = false;
$has_guru = false;
foreach ($active_roles as $r) {
    if (strtolower($r) === 'kepala sekolah' || strtolower($r) === 'kepsek') {
        $has_kepsek = true;
    } else if (strtolower($r) !== 'siswa') {
        $has_guru = true;
    }
}

$total_siswa = 0;
if ($has_siswa) {
    $stmtS = $db->query("SELECT COUNT(id) FROM perf_siswa WHERE status = 1");
    $total_siswa = (int)$stmtS->fetchColumn();
}

$total_kepsek = 0;
if ($has_kepsek) {
    $stmtK = $db->query("SELECT COUNT(id) FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
    $total_kepsek = (int)$stmtK->fetchColumn();
}

$stmtP = $db->query("SELECT id, nama, jenis_ptk FROM perf_ptk WHERE status = 1 ORDER BY nama ASC LIMIT 10");
$ptks = $stmtP->fetchAll(PDO::FETCH_ASSOC);

foreach ($ptks as $p) {
    $total_expected = 0;
    $ptk_id = $p['id'];
    $jenis_ptk = $p['jenis_ptk'];

    if (strtolower($jenis_ptk) === 'kepala sekolah') {
        if (role_targets_jenis_ptk($db, $periode_id, 'Kepala Sekolah', 'Kepala Sekolah')) {
            $total_expected = $total_kepsek;
        }
    } else {
        // Siswa
        if ($has_siswa && role_targets_jenis_ptk($db, $periode_id, 'Siswa', $jenis_ptk)) {
            $jp = strtolower($jenis_ptk);
            if (strpos($jp, 'tu') !== false || strpos($jp, 'administrasi') !== false || strpos($jp, 'pustakawan') !== false || strpos($jp, 'kebersihan') !== false || strpos($jp, 'keamanan') !== false || strpos($jp, 'it-support') !== false) {
                // If it's TU/Admin, all students evaluate them? 
                // Wait! In list_laporan, ONLY TU was added total_siswa.
                // Let's use the exact logic they want.
                $total_expected += $total_siswa;
            } else {
                $stmtS = $db->prepare("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = ? AND periode_id = ?");
                $stmtS->execute([$ptk_id, $periode_id]);
                $total_expected += (int)$stmtS->fetchColumn();
            }
        }
        
        // Kepsek
        if ($has_kepsek && role_targets_jenis_ptk($db, $periode_id, 'Kepala Sekolah', $jenis_ptk)) {
            $total_expected += $total_kepsek;
        }
        
        // Guru (Diri Sendiri & Sejawat)
        if ($has_guru) {
            if (role_targets_jenis_ptk($db, $periode_id, 'Diri Sendiri', $jenis_ptk)) {
                $total_expected += 1;
            }
            if (role_targets_jenis_ptk($db, $periode_id, 'Teman Sejawat', $jenis_ptk)) {
                $stmtPeer = $db->prepare("SELECT COUNT(*) FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = ? AND periode_id = ?");
                $stmtPeer->execute([$ptk_id, $periode_id]);
                $total_expected += (int)$stmtPeer->fetchColumn();
            }
        }
    }

    if ($total_expected === 0) $total_expected = 1;

    $stmtAns = $db->prepare("SELECT COUNT(DISTINCT penilai_id, penilai_type) FROM perf_penilaian WHERE dinilai_ptk_id = ? AND periode_id = ?");
    $stmtAns->execute([$ptk_id, $periode_id]);
    $answered = (int)$stmtAns->fetchColumn();

    echo "{$p['nama']} ({$p['jenis_ptk']}) - Answered: $answered, Expected: $total_expected\n";
}
?>
