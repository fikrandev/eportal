<?php
/**
 * Migration V7
 * - Mengubah kolom jenis_ptk di tabel perf_ptk menjadi VARCHAR(100) 
 *   agar bisa menyimpan Tupoksi custom dari E-Portal yang sebelumnya ditolak oleh ENUM.
 * - Melakukan sinkronisasi data jenis_ptk (tupoksi) yang kosong dari tabel users.
 */
require_once __DIR__ . '/api/config.php';

try {
    $pdo = db();
    
    echo "<h2>Migrasi V7: Perbaikan Struktur E-Performance</h2>";
    echo "<ul>";
    
    // 1. Alter table perf_ptk
    try {
        $pdo->exec("ALTER TABLE `perf_ptk` MODIFY `jenis_ptk` VARCHAR(100) NOT NULL DEFAULT '-'");
        echo "<li>[OK] Berhasil mengubah tipe data <code>jenis_ptk</code> menjadi VARCHAR(100) pada tabel <code>perf_ptk</code>.</li>";
    } catch (PDOException $e) {
        echo "<li>[INFO] Gagal mengubah tipe data <code>jenis_ptk</code> atau kolom sudah benar: " . htmlspecialchars($e->getMessage()) . "</li>";
    }
    
    // 2. Sinkronisasi data yang kosong/salah karena sebelumnya tertolak oleh ENUM
    try {
        // Update jenis_ptk from users.tupoksi based on niy = username
        $stmt = $pdo->query("
            UPDATE perf_ptk p
            JOIN users u ON p.niy = u.username
            SET p.jenis_ptk = IF(u.tupoksi IS NULL OR u.tupoksi = '' OR u.tupoksi = '-', 'guru', u.tupoksi)
            WHERE p.jenis_ptk = '' OR p.jenis_ptk = '-' OR p.jenis_ptk IS NULL
        ");
        $rowCount = $stmt->rowCount();
        echo "<li>[OK] Berhasil menyinkronkan $rowCount data tupoksi guru yang sebelumnya kosong.</li>";
    } catch (PDOException $e) {
        echo "<li>[ERR] Gagal menyinkronkan data tupoksi: " . htmlspecialchars($e->getMessage()) . "</li>";
    }
    
    echo "</ul>";
    echo "<p><b>Migrasi V7 Selesai!</b> Silakan refresh halaman E-Performance, data Tupoksi sekarang sudah muncul.</p>";
    
} catch (Exception $e) {
    echo "<h3>Error Koneksi Database:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
