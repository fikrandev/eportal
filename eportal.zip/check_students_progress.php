<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
$student_ids = [330,331,336,337,338,580,581,582,583,584,585,586,587,588,589,590,591];

foreach($student_ids as $sid) {
    // Get total expected for this student
    $stmtS = $db->query("SELECT perf_user_id, nama_siswa FROM perf_siswa WHERE id = $sid");
    $s = $stmtS->fetch(PDO::FETCH_ASSOC);
    $p_id = $s['perf_user_id'];
    
    // targets
    $stmtTargets = $db->prepare("
        SELECT jenis_ptk, COUNT(id) as jml 
        FROM perf_ptk 
        WHERE status = 1 AND (
            jenis_ptk = 'tu' 
            OR id IN (SELECT perf_ptk_id FROM perf_siswa_guru WHERE perf_siswa_id = ?)
        )
        GROUP BY jenis_ptk
    ");
    $stmtTargets->execute([$sid]);
    $target_groups = $stmtTargets->fetchAll(PDO::FETCH_ASSOC);

    $stmtQ_dyn = $db->prepare("
        SELECT COUNT(id) FROM perf_instrumen WHERE periode_id = ? AND is_manual = 0 AND (
            (
                (FIND_IN_SET(?, target_jabatan) > 0 OR FIND_IN_SET(?, target_jabatan) > 0)
                AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0)
            )
            OR
            (
                FIND_IN_SET(?, target_jabatan) > 0 
                AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0 OR FIND_IN_SET(?, target_dinilai) > 0)
            )
            OR
            (FIND_IN_SET(?, target_jabatan) > 0 AND FIND_IN_SET(?, target_dinilai) > 0)
        )
    ");

    $total_expected = 0;
    foreach ($target_groups as $tg) {
        $t_jenis = $tg['jenis_ptk'] ?: 'Guru';
        $stmtQ_dyn->execute([
            $periode_id,
            'Siswa', 'Siswa', $t_jenis,
            'Siswa', $t_jenis, 'Siswa',
            $t_jenis, 'Siswa'
        ]);
        $q_per_target = (int)$stmtQ_dyn->fetchColumn();
        $total_expected += ($q_per_target * $tg['jml']);
    }
    
    if ($total_expected === 0) $total_expected = 1;
    $stmtAns = $db->prepare("SELECT COUNT(*) FROM perf_penilaian WHERE penilai_id = ? AND periode_id = ?");
    $stmtAns->execute([$p_id, $periode_id]);
    $answered = (int)$stmtAns->fetchColumn();
    
    echo $s['nama_siswa'] . " - Answered: $answered, Expected: $total_expected, Perc: " . round(($answered / $total_expected) * 100) . "%\n";
}
?>
