<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT kategori, target_dinilai FROM perf_instrumen WHERE is_manual = 1");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
