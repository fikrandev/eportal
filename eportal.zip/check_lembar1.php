<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
// Get Amaliya PTK ID
$stmt = $db->query("SELECT id FROM perf_ptk WHERE nama LIKE '%AMALIYA%' LIMIT 1");
$ptk_id = $stmt->fetchColumn();

$_GET['ptk_id'] = $ptk_id;
$_GET['periode_id'] = $periode_id;

ob_start();
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/cetak_lampiran.php';
$out = ob_get_clean();

// Extract the first table (Lembar 1)
if (preg_match('/<table class="main-table">(.*?)<\/table>/s', $out, $matches)) {
    echo strip_tags(str_replace('</tr>', "</tr>\n", $matches[1]));
} else {
    echo "Table not found";
}
?>
