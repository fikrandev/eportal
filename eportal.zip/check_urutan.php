<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT kategori, urutan, id, target_dinilai FROM perf_instrumen WHERE is_manual = 1 ORDER BY urutan ASC, id ASC");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
