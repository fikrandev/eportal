<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT data FROM perf_penilaian_manual WHERE ptk_id = (SELECT id FROM perf_ptk WHERE nama = 'ABDUL AZIZI, S.Pd.')");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
