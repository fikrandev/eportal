<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT id, target_jabatan, target_dinilai, is_manual FROM perf_instrumen WHERE periode_id = 6");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
