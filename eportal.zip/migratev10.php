<?php
/**
 * Migration V10
 * - Menambahkan kolom mapel (Mata Pelajaran) ke tabel users
 */
require_once __DIR__ . '/api/config.php';

try {
    $pdo = db();
    
    echo "<h2>Migrasi V10: Menambah Kolom Mata Pelajaran</h2>";
    echo "<ul>";
    
    // Add mapel to users
    try {
        $pdo->exec("ALTER TABLE `users` ADD COLUMN `mapel` VARCHAR(255) NULL AFTER `jabatan`");
        echo "<li>[OK] Berhasil menambahkan kolom <code>mapel</code> ke tabel <code>users</code>.</li>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
            echo "<li>[INFO] Kolom <code>mapel</code> sudah ada pada tabel <code>users</code>.</li>";
        } else {
            echo "<li>[ERR] Gagal menambahkan kolom mapel: " . htmlspecialchars($e->getMessage()) . "</li>";
        }
    }

    echo "</ul>";
    echo "<p><strong>Migrasi selesai.</strong></p>";
    
} catch (Exception $e) {
    echo "<p style='color:red;'>Koneksi database gagal: " . htmlspecialchars($e->getMessage()) . "</p>";
}
