<?php
/**
 * Migration v4 - E-Xam Card Teacher Access
 */
require_once __DIR__ . '/api/config.php';

$pdo = db();

echo "<h3>Migration V4</h3><pre>";

$queries = [
    "CREATE TABLE IF NOT EXISTS `xam_teacher_access` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `access_role` varchar(50) NOT NULL DEFAULT 'wali_kelas',
        `kelas` varchar(50) NOT NULL,
        `status` tinyint(1) NOT NULL DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_user_id` (`user_id`),
        KEY `idx_xam_kelas` (`kelas`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;",

    "ALTER TABLE `xam_exams` ADD COLUMN IF NOT EXISTS `card_template` VARCHAR(255) DEFAULT NULL AFTER `status`;"
];

foreach ($queries as $sql) {
    try {
        $pdo->exec($sql);
        echo "[OK] Query executed successfully.\n";
    } catch (Exception $e) {
        echo "[ERR] " . $e->getMessage() . "\n";
    }
}

echo "</pre>";
