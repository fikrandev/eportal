<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
$stmtR = $db->prepare("SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = ?");
$stmtR->execute([$periode_id]);
$active_roles = $stmtR->fetchAll(PDO::FETCH_COLUMN);
$active_roles = array_map('strtolower', $active_roles);

$has_siswa = in_array('siswa', $active_roles);
$has_kepsek = in_array('kepala sekolah', $active_roles) || in_array('kepsek', $active_roles);
$has_guru = false;
foreach ($active_roles as $r) {
    if ($r !== 'siswa' && $r !== 'kepala sekolah' && $r !== 'kepsek') {
        $has_guru = true;
        break;
    }
}

$total_siswa = 0;
if ($has_siswa) {
    $stmtS = $db->query("SELECT COUNT(id) FROM perf_siswa WHERE status = 1");
    $total_siswa = (int)$stmtS->fetchColumn();
}

$total_kepsek = 0;
if ($has_kepsek) {
    $stmtK = $db->query("SELECT COUNT(id) FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
    $total_kepsek = (int)$stmtK->fetchColumn();
}

$stmtP = $db->query("SELECT id, nama, jenis_ptk FROM perf_ptk WHERE id = 850 AND status = 1 ORDER BY nama ASC LIMIT 10");
$ptks = $stmtP->fetchAll(PDO::FETCH_ASSOC);

foreach ($ptks as $p) {
    $total_expected = 0;
    $ptk_id = $p['id'];

    if (strtolower($p['jenis_ptk']) === 'kepala sekolah') {
        $total_expected = $total_kepsek;
    } else {
        if ($has_siswa) {
            if (strtolower($p['jenis_ptk']) === 'tu') {
                $total_expected += $total_siswa;
            } else {
                $stmtS = $db->prepare("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = ? AND periode_id = ?");
                $stmtS->execute([$ptk_id, $periode_id]);
                $c = (int)$stmtS->fetchColumn();
                echo "Added $c from Siswa\n";
                $total_expected += $c;
            }
        }
        
        if ($has_kepsek) {
            echo "Added $total_kepsek from Kepsek\n";
            $total_expected += $total_kepsek;
        }
        
        if ($has_guru) {
            echo "Added 1 from Diri Sendiri\n";
            $total_expected += 1; // Diri Sendiri
            $stmtPeer = $db->prepare("SELECT COUNT(*) FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = ? AND periode_id = ?");
            $stmtPeer->execute([$ptk_id, $periode_id]);
            $peer_count = (int)$stmtPeer->fetchColumn();
            echo "Added $peer_count from Sejawat\n";
            $total_expected += $peer_count;
        }
    }

    echo "Final Total Expected: $total_expected\n";
}
?>
