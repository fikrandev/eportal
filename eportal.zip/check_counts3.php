<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT perf_ptk_id, COUNT(*) FROM perf_siswa_guru WHERE periode_id=6 GROUP BY perf_ptk_id");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
