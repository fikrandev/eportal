<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = (SELECT id FROM perf_ptk WHERE nama LIKE '%SOEDJOKO%')");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
?>
