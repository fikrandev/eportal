<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
print_r($db->query('SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = 6')->fetchAll(PDO::FETCH_COLUMN));
?>
