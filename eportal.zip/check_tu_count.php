<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$stmt = db()->query("SELECT COUNT(*) FROM perf_ptk WHERE jenis_ptk = 'tu'");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
?>
