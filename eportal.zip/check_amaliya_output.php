<?php
function perf_require_admin() {}
function db() {
    global $db_conn;
    if (!$db_conn) {
        $db_conn = new PDO('mysql:host=localhost;dbname=wa_akad', 'root', '');
        $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    return $db_conn;
}
$db = db();
$_GET['periode_id'] = 6;
ob_start();
define('REKAP_INCLUDED', true);
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/cetak_rekap_keseluruhan.php';
$output = ob_get_clean();

preg_match('/AMALIYA MUFIDAH.*?<\/tr>/s', $output, $m1);
echo "Amaliya:\n"; print_r($m1);

preg_match('/SOEDJOKO.*?<\/tr>/s', $output, $m2);
echo "\nSoedjoko:\n"; print_r($m2);
?>
