<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT COUNT(*) FROM perf_penilaian p JOIN perf_ptk pt ON p.dinilai_ptk_id = pt.id WHERE pt.jenis_ptk = 'Kepala TU'");
echo "Angket Kepala TU: " . $stmt->fetchColumn() . "\n";
?>
