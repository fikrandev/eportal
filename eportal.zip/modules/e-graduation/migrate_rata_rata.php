<?php
/**
 * Migration: Add rata_rata column to students table
 */
require_once __DIR__ . '/../../api/config.php';

header('Content-Type: text/plain');

try {
    $db = db();
    echo "Checking database...\n";

    // Check if column exists
    $columns = $db->query("SHOW COLUMNS FROM students LIKE 'rata_rata'")->fetchAll();
    if (empty($columns)) {
        echo "Adding 'rata_rata' column to 'students' table...\n";
        $db->exec("ALTER TABLE students ADD COLUMN rata_rata DECIMAL(5,2) DEFAULT NULL AFTER status");
        echo "Success: Column 'rata_rata' added.\n";
    } else {
        echo "Info: Column 'rata_rata' already exists.\n";
    }

    echo "\nMigration complete.";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
