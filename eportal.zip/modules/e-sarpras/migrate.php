<?php
/**
 * E-Sarpras Database Migration Script
 * Consolidates all schema changes into a single idempotent script
 * Run this file to initialize or update the E-Sarpras database
 */

require_once __DIR__ . '/../../api/config.php';

echo "<h2>E-Sarpras Database Migration</h2>";
echo "<pre>";

$pdo = db();

/**
 * Helper to add columns safely (Idempotent)
 */
function addColumn($table, $column, $definition) {
    global $pdo;
    try {
        $check = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'")->fetch();
        if (!$check) {
            $pdo->exec("ALTER TABLE `$table` ADD COLUMN $column $definition");
            echo "[OK] Added column `$column` to `$table`\n";
        } else {
            echo "[SKIP] Column `$column` already exists in `$table`\n";
        }
    } catch (Exception $e) {
        echo "[ERR] Failed to add column `$column` to `$table`: " . $e->getMessage() . "\n";
    }
}

// 1. BASELINE TABLES (From e_sarpras.sql + Incremental)
$tables = [
    // Core Infrastructure
    "kategori_sarpras" => "CREATE TABLE IF NOT EXISTS `kategori_sarpras` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `nama` VARCHAR(100) NOT NULL,
        `kode` VARCHAR(10) NOT NULL,
        `jenis` ENUM('sarana', 'prasarana') NOT NULL DEFAULT 'sarana',
        `keterangan` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode` (`kode`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "tanah" => "CREATE TABLE IF NOT EXISTS `tanah` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `nama` VARCHAR(150) NOT NULL,
        `kode_tanah` VARCHAR(50) DEFAULT NULL,
        `lokasi` TEXT DEFAULT NULL,
        `lintang` VARCHAR(50) DEFAULT NULL,
        `bujur` VARCHAR(50) DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
        `no_sertifikat` VARCHAR(100) DEFAULT NULL,
        `tgl_sertifikat` DATE DEFAULT NULL,
        `kepemilikan` VARCHAR(50) DEFAULT 'Milik Sendiri',
        `keterangan` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "bangunan" => "CREATE TABLE IF NOT EXISTS `bangunan` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `tanah_id` INT(11) UNSIGNED NOT NULL,
        `nama` VARCHAR(150) NOT NULL,
        `kode_bangunan` VARCHAR(50) DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
        `tahun_perolehan` YEAR DEFAULT NULL,
        `keterangan` TEXT DEFAULT NULL,
        PRIMARY KEY (`id`),
        CONSTRAINT `fk_bang_tanah` FOREIGN KEY (`tanah_id`) REFERENCES `tanah`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "ruang" => "CREATE TABLE IF NOT EXISTS `ruang` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `bangunan_id` INT(11) UNSIGNED NOT NULL,
        `pj_id` INT(11) UNSIGNED DEFAULT NULL,
        `nama` VARCHAR(100) NOT NULL,
        `kode_ruang` VARCHAR(20) NOT NULL,
        `panjang_m` DECIMAL(10,2) DEFAULT NULL,
        `lebar_m` DECIMAL(10,2) DEFAULT NULL,
        `luas_m2` DECIMAL(10,2) DEFAULT NULL,
        `luas_plester_m2` DECIMAL(10,2) DEFAULT NULL,
        `lantai_ke` INT(11) DEFAULT 1,
        `kapasitas` INT(11) DEFAULT NULL,
        `keterangan` TEXT DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode_ruang` (`kode_ruang`),
        CONSTRAINT `fk_ruang_bang` FOREIGN KEY (`bangunan_id`) REFERENCES `bangunan`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    // Inventory
    "sarpras" => "CREATE TABLE IF NOT EXISTS `sarpras` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `ruang_id` INT(11) UNSIGNED NOT NULL,
        `kategori_id` INT(11) UNSIGNED NOT NULL,
        `nama` VARCHAR(200) NOT NULL,
        `kode_inventaris` VARCHAR(50) NOT NULL,
        `merk` VARCHAR(100) DEFAULT NULL,
        `spesifikasi` TEXT DEFAULT NULL,
        `satuan` VARCHAR(50) DEFAULT 'Unit',
        `jumlah` INT(11) NOT NULL DEFAULT 1,
        `harga_perolehan` DECIMAL(15,2) NOT NULL DEFAULT 0,
        `tahun_perolehan` YEAR NOT NULL,
        `sumber_dana` VARCHAR(50) DEFAULT 'BOS',
        `kondisi_baik` INT(11) NOT NULL DEFAULT 0,
        `kondisi_rusak_ringan` INT(11) NOT NULL DEFAULT 0,
        `kondisi_rusak_berat` INT(11) NOT NULL DEFAULT 0,
        `keterangan` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_kode_inv` (`kode_inventaris`),
        CONSTRAINT `fk_s_ruang` FOREIGN KEY (`ruang_id`) REFERENCES `ruang`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    // Photos
    "sarpras_foto" => "CREATE TABLE IF NOT EXISTS `sarpras_foto` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `foto_path` VARCHAR(255) NOT NULL,
        `keterangan` VARCHAR(255),
        `urutan` INT DEFAULT 0,
        CONSTRAINT `fk_f_s` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
    )",

    // Activity & Reports
    "sarpras_periodik" => "CREATE TABLE IF NOT EXISTS `sarpras_periodik` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `periode` VARCHAR(20),
        `tahun` YEAR,
        `kondisi_baik` INT,
        `kondisi_rr` INT,
        `kondisi_rb` INT,
        `keterangan` TEXT,
        `updated_by` INT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",

    "sarpras_berita_acara" => "CREATE TABLE IF NOT EXISTS `sarpras_berita_acara` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `nomor_ba` VARCHAR(100) NOT NULL,
        `tanggal_ba` DATE NOT NULL,
        `tahun_ba` YEAR,
        `file_ba` VARCHAR(255),
        `keterangan` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_by` INT
    )",

    "sarpras_perbaikan" => "CREATE TABLE IF NOT EXISTS `sarpras_perbaikan` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `berita_acara_id` INT NULL,
        `tanggal` DATE,
        `tanggal_selesai` DATE,
        `biaya` DECIMAL(15,2) DEFAULT 0,
        `jumlah` INT DEFAULT 1,
        `deskripsi` TEXT,
        `status` ENUM('Diajukan', 'Proses', 'Selesai', 'Batal', 'Penghapusan') DEFAULT 'Diajukan',
        `updated_by` INT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT `fk_perb_s` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
    )",

    // PJ & People
    "sarpras_pj" => "CREATE TABLE IF NOT EXISTS `sarpras_pj` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `bangunan_id` INT(11) UNSIGNED NULL,
        `user_id` INT NULL,
        `nama` VARCHAR(150),
        `nip` VARCHAR(50),
        `jabatan` VARCHAR(100),
        `keterangan` TEXT
    )",

    // Borrowing System
    "sarpras_peminjaman" => "CREATE TABLE IF NOT EXISTS `sarpras_peminjaman` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NULL,
        `nama_peminjam` VARCHAR(255) NOT NULL,
        `jabatan` VARCHAR(255),
        `no_hp` VARCHAR(50),
        `asal_unit` VARCHAR(150),
        `nama_kegiatan` VARCHAR(255),
        `sarpras_id` INT(11) UNSIGNED NOT NULL,
        `jumlah` INT DEFAULT 1,
        `kondisi_sebelum` TEXT,
        `kondisi_sesudah` TEXT,
        `tanggal_pinjam DATE` NOT NULL,
        `tanggal_kembali_rencana` DATE,
        `tanggal_kembali_aktual` DATE,
        `status` ENUM('Dipinjam', 'Dikembalikan') DEFAULT 'Dipinjam',
        `catatan` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_by` INT
    )",

    // Roles & Scoping
    "sarpras_roles_def" => "CREATE TABLE IF NOT EXISTS `sarpras_roles_def` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `nama` VARCHAR(100) NOT NULL,
        `deskripsi` TEXT,
        `is_locked` TINYINT(1) DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",

    "sarpras_role_permissions" => "CREATE TABLE IF NOT EXISTS `sarpras_role_permissions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `role_id` INT NOT NULL,
        `permission_key` VARCHAR(100) NOT NULL,
        UNIQUE KEY `uk_role_perm` (`role_id`, `permission_key`)
    )",

    "sarpras_roles" => "CREATE TABLE IF NOT EXISTS `sarpras_roles` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` INT NOT NULL,
        `custom_role_id` INT NULL,
        `role` VARCHAR(50),
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `uk_user` (`user_id`)
    )",

    "sequence_tracker" => "CREATE TABLE IF NOT EXISTS `sequence_tracker` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `kategori_kode` VARCHAR(10),
        `tahun` YEAR,
        `last_seq` INT DEFAULT 0,
        UNIQUE KEY `uk_seq` (`kategori_kode`, `tahun`)
    )"
];

// Execute table creations
foreach ($tables as $name => $sql) {
    try {
        $pdo->exec($sql);
        echo "[OK] Table `$name` ensured.\n";
    } catch (Exception $e) {
        echo "[ERR] Table `$name` failed: " . $e->getMessage() . "\n";
    }
}

// 2. COLUMN EVOLUTIONS
echo "\n--- COLUMN UPDATES ---\n";
addColumn('sarpras', 'kepemilikan', "VARCHAR(50) DEFAULT 'Milik Sendiri' AFTER sumber_dana");
addColumn('sarpras', 'jenis_sarana', "VARCHAR(100) DEFAULT NULL AFTER kepemilikan");
addColumn('sarpras', 'no_polisi', "VARCHAR(20) DEFAULT NULL AFTER jenis_sarana");
addColumn('sarpras', 'no_bpkb', "VARCHAR(30) DEFAULT NULL AFTER no_polisi");
addColumn('sarpras', 'alamat', "TEXT DEFAULT NULL AFTER no_bpkb");
addColumn('sarpras', 'grup_pintasan', "VARCHAR(50) DEFAULT NULL");
addColumn('sarpras', 'bk_id', "INT NULL COMMENT 'Ref to Book Classification' AFTER kategori_id");

addColumn('sarpras_pj', 'user_id', "INT NULL AFTER nip");
addColumn('sarpras_pj', 'jabatan', "VARCHAR(100) AFTER nip");

addColumn('sarpras_perbaikan', 'berita_acara_id', "INT NULL AFTER sarpras_id");
addColumn('sarpras_perbaikan', 'jumlah', "INT DEFAULT 1 AFTER biaya");

addColumn('ruang', 'pj_id', "INT(11) UNSIGNED NULL AFTER bangunan_id");

echo "\n--- MIGRATION COMPLETED ---\n";
echo "</pre>";
echo "<a href='index.php'>Back to Dashboard</a>";
