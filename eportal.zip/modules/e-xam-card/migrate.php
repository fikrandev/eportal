<?php
/**
 * E-Xam Card module migration.
 */
require_once __DIR__ . '/../../api/config.php';

$pdo = db();

echo "<h3>E-Xam Card Migration</h3><pre>";

$queries = [
    "CREATE TABLE IF NOT EXISTS `xam_exams` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `academic_year_id` INT(11) UNSIGNED NOT NULL,
        `exam_name` VARCHAR(150) NOT NULL,
        `exam_start_date` DATE NOT NULL,
        `exam_end_date` DATE NOT NULL,
        `status` TINYINT(1) NOT NULL DEFAULT 1,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_xam_exam_year` (`academic_year_id`),
        CONSTRAINT `fk_xam_exam_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `xam_exam_settings` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `letter_manual_no` VARCHAR(30) DEFAULT NULL,
        `letter_code` VARCHAR(120) NOT NULL DEFAULT 'I04.1/SMA.WH1',
        `letter_date` DATE DEFAULT NULL,
        `sign_date` DATE DEFAULT NULL,
        `headmaster_user_id` INT(11) UNSIGNED DEFAULT NULL,
        `headmaster_name` VARCHAR(150) DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_setting_exam` (`exam_id`),
        KEY `idx_xam_headmaster` (`headmaster_user_id`),
        CONSTRAINT `fk_xam_setting_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
        CONSTRAINT `fk_xam_setting_headmaster` FOREIGN KEY (`headmaster_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `xam_exam_classes` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `kelas` VARCHAR(50) NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_exam_class` (`exam_id`, `kelas`),
        KEY `idx_xam_exam_class_exam` (`exam_id`),
        CONSTRAINT `fk_xam_exam_class_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `xam_exam_students` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `exam_id` INT(11) UNSIGNED NOT NULL,
        `student_id` INT(11) UNSIGNED NOT NULL,
        `ruang_ujian` VARCHAR(100) DEFAULT NULL,
        `username` VARCHAR(60) NOT NULL,
        `password_hash` VARCHAR(255) DEFAULT NULL,
        `password_plain` VARCHAR(80) DEFAULT NULL,
        `status` ENUM('OKE','DITANGGUHKAN') NOT NULL DEFAULT 'DITANGGUHKAN',
        `suspension_note` VARCHAR(255) DEFAULT 'Silakan hubungi Wali Kelas / Waka. Kesiswaan',
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uk_xam_exam_student` (`exam_id`, `student_id`),
        KEY `idx_xam_exam_student_exam` (`exam_id`),
        KEY `idx_xam_exam_student_status` (`status`),
        CONSTRAINT `fk_xam_exam_student_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
        CONSTRAINT `fk_xam_exam_student_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($queries as $sql) {
    try {
        $pdo->exec($sql);
        echo "[OK] Query executed\n";
    } catch (Exception $e) {
        echo "[ERR] " . $e->getMessage() . "\n";
    }
}

try {
    $icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10"/><path d="M7 12h10"/><path d="M7 16h6"/></svg>';
    $stmt = $pdo->prepare("\n        INSERT INTO modules (nama_modul, slug, deskripsi, icon_svg, url_path, color, urutan, status)
        VALUES ('E-Xam Card', 'e-xam-card', 'Manajemen kartu ujian siswa', ?, 'modules/e-xam-card/', '#0F766E', 5, 1)
        ON DUPLICATE KEY UPDATE
            nama_modul = VALUES(nama_modul),
            deskripsi = VALUES(deskripsi),
            icon_svg = VALUES(icon_svg),
            url_path = VALUES(url_path),
            color = VALUES(color),
            status = VALUES(status)
    ");
    $stmt->execute([$icon]);
    echo "[OK] Module E-Xam Card ensured\n";
} catch (Exception $e) {
    echo "[ERR] module seed failed: " . $e->getMessage() . "\n";
}

echo "</pre>";
