<?php
/**
 * E-Examination module registration & migration.
 */
require_once __DIR__ . '/../../api/config.php';

$pdo = db();

echo "<h3>E-Examination Migration</h3><pre>\n";

try {
    $icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>';
    
    // Check if module already exists by slug to update its urutan or insert new
    $stmt = $pdo->prepare("
        INSERT INTO modules (nama_modul, slug, deskripsi, icon_svg, url_path, color, urutan, status)
        VALUES ('E-Examination', 'e-examination', 'Computer Based Test & AI Grading', ?, 'modules/e-examination/', '#2563EB', 6, 1)
        ON DUPLICATE KEY UPDATE
            nama_modul = VALUES(nama_modul),
            deskripsi = VALUES(deskripsi),
            icon_svg = VALUES(icon_svg),
            url_path = VALUES(url_path),
            color = VALUES(color),
            status = VALUES(status)
    ");
    $stmt->execute([$icon]);
    echo "[OK] Module E-Examination registered successfully\n";
} catch (Exception $e) {
    echo "[ERR] module registration failed: " . $e->getMessage() . "\n";
}

echo "</pre>";
