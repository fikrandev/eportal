<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmtR = $db->prepare('SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = 6');
$stmtR->execute();
$roles = $stmtR->fetchAll(PDO::FETCH_COLUMN);
$active_roles = array_map('strtolower', $roles);
print_r($active_roles);

$has_guru = false;
foreach ($active_roles as $r) {
    if ($r !== 'siswa' && $r !== 'kepala sekolah' && $r !== 'kepsek') {
        $has_guru = true;
        break;
    }
}
echo "Has Guru: " . ($has_guru ? 'true' : 'false') . "\n";
$has_kepsek = in_array('kepala sekolah', $active_roles) || in_array('kepsek', $active_roles);
echo "Has Kepsek: " . ($has_kepsek ? 'true' : 'false') . "\n";
?>
