<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
echo "Kepsek: " . $db->query("SELECT COUNT(id) FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1")->fetchColumn() . "\n";
echo "Siswa: " . $db->query("SELECT COUNT(id) FROM perf_siswa WHERE status = 1")->fetchColumn() . "\n";
echo "Total from sejawat (PTK=4) " . $db->query("SELECT COUNT(*) FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = 4 AND periode_id = 6")->fetchColumn() . "\n";
?>
