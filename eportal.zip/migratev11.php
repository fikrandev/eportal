<?php
require_once __DIR__ . '/api/config.php';

echo "<h2>Migrasi v11 - E-Performance Aturan Sejawat</h2>";
echo "<pre style='background:#1e293b; color:#fbbf24; padding:20px; border-radius:8px; overflow:auto;'>";

$pdo = db();

try {
    $sql = "
    CREATE TABLE IF NOT EXISTS `perf_aturan_sejawat` (
      `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
      `periode_id` int(11) unsigned NOT NULL,
      `penilai_jenis` varchar(100) NOT NULL,
      `dinilai_jenis` varchar(100) NOT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`),
      KEY `periode_id` (`periode_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $pdo->exec($sql);
    echo "[OK] Tabel perf_aturan_sejawat berhasil dibuat atau sudah ada.\n";
    
} catch (Exception $e) {
    echo "[ERR] Gagal membuat tabel perf_aturan_sejawat: " . $e->getMessage() . "\n";
}

echo "</pre>";
echo "<a href='index.php' style='display:inline-block; margin-top:20px; padding:10px 20px; background:#10B981; color:white; text-decoration:none; border-radius:5px;'>Kembali ke Beranda</a>";
