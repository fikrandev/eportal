<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
// Let's run the exact same logic as CURRENT list_laporan to see the numbers
$periode_id = 6;
$stmtR = $db->prepare("SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = ?");
$stmtR->execute([$periode_id]);
$active_roles = $stmtR->fetchAll(PDO::FETCH_COLUMN);
$active_roles = array_map('strtolower', $active_roles);

$has_siswa = in_array('siswa', $active_roles);
$has_kepsek = in_array('kepala sekolah', $active_roles) || in_array('kepsek', $active_roles);
$has_guru = false;
foreach ($active_roles as $r) {
    if ($r !== 'siswa' && $r !== 'kepala sekolah' && $r !== 'kepsek') {
        $has_guru = true;
        break;
    }
}

$total_siswa = 0;
if ($has_siswa) {
    $stmtS = $db->query("SELECT COUNT(id) FROM perf_siswa WHERE status = 1");
    $total_siswa = (int)$stmtS->fetchColumn();
}

$total_kepsek = 0;
if ($has_kepsek) {
    $stmtK = $db->query("SELECT COUNT(id) FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
    $total_kepsek = (int)$stmtK->fetchColumn();
}

$stmtP = $db->query("SELECT id, nama, jenis_ptk FROM perf_ptk WHERE status = 1 ORDER BY nama ASC LIMIT 10");
$ptks = $stmtP->fetchAll(PDO::FETCH_ASSOC);

$laporan_data = [];
foreach ($ptks as $p) {
    $total_expected = 0;
    $ptk_id = $p['id'];

    if (strtolower($p['jenis_ptk']) === 'kepala sekolah') {
        $total_expected = $total_kepsek;
    } else {
        if ($has_siswa) {
            if (strtolower($p['jenis_ptk']) === 'tu') {
                $total_expected += $total_siswa;
            } else {
                $stmtS = $db->prepare("SELECT COUNT(*) FROM perf_siswa_guru WHERE perf_ptk_id = ? AND periode_id = ?");
                $stmtS->execute([$ptk_id, $periode_id]);
                $total_expected += (int)$stmtS->fetchColumn();
            }
        }
        if ($has_kepsek) {
            $total_expected += $total_kepsek;
        }
        if ($has_guru) {
            $total_expected += 1; // Diri Sendiri
            $stmtPeer = $db->prepare("SELECT COUNT(*) FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = ? AND periode_id = ?");
            $stmtPeer->execute([$ptk_id, $periode_id]);
            $total_expected += (int)$stmtPeer->fetchColumn();
        }
    }

    if ($total_expected === 0) $total_expected = 1;

    $stmtAns = $db->prepare("SELECT COUNT(DISTINCT penilai_id, penilai_type) FROM perf_penilaian WHERE dinilai_ptk_id = ? AND periode_id = ?");
    $stmtAns->execute([$ptk_id, $periode_id]);
    $answered = (int)$stmtAns->fetchColumn();

    $laporan_data[] = [
        'nama' => $p['nama'],
        'jenis' => $p['jenis_ptk'],
        'answered' => $answered,
        'total' => $total_expected,
        'percentage' => round(($answered / $total_expected) * 100)
    ];
}
print_r($laporan_data);
?>
