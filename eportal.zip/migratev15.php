<?php
require_once __DIR__ . '/api/config.php';

try {
    $db = db();
    
    echo "Memulai migrasi v15 (RBAC E-Performance)...\n";
    
    // 1. Buat tabel perf_roles
    $db->exec("
    CREATE TABLE IF NOT EXISTS `perf_roles` (
      `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
      `role_slug` VARCHAR(50) NOT NULL,
      `role_name` VARCHAR(100) NOT NULL,
      `permissions` TEXT DEFAULT NULL,
      `is_system` TINYINT(1) NOT NULL DEFAULT 0,
      `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      UNIQUE KEY `uk_role_slug` (`role_slug`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    echo "- Tabel perf_roles berhasil dibuat atau sudah ada.\n";
    
    // 2. Insert data role bawaan
    $adminPerms = json_encode(['dashboard','ptk','siswa','periode','instrumen','progress','hasil','penilaian','roles','users']);
    $userPerms = json_encode(['dashboard','penilaian']);
    
    $stmt = $db->prepare("INSERT IGNORE INTO perf_roles (role_slug, role_name, permissions, is_system) VALUES (?, ?, ?, 1)");
    
    $roles = [
        ['admin', 'Administrator', $adminPerms],
        ['kepsek', 'Kepala Sekolah', $userPerms],
        ['guru', 'Guru', $userPerms],
        ['tu', 'Tata Usaha', $userPerms],
        ['it', 'IT Support', $userPerms],
        ['pustakawan', 'Pustakawan', $userPerms],
        ['siswa', 'Siswa', $userPerms]
    ];
    
    foreach ($roles as $r) {
        $stmt->execute([$r[0], $r[1], $r[2]]);
    }
    echo "- Data role bawaan berhasil disisipkan.\n";
    
    // 3. Ubah kolom role di perf_users
    // Karena saat ini ENUM, kita ubah jadi VARCHAR
    $db->exec("ALTER TABLE perf_users MODIFY COLUMN role VARCHAR(50) NOT NULL DEFAULT 'guru'");
    echo "- Tipe kolom role pada tabel perf_users telah diubah ke VARCHAR(50).\n";
    
    echo "\nMigrasi v15 selesai!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
