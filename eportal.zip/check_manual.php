<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT p.nama, p.jenis_ptk, m.data FROM perf_penilaian_manual m JOIN perf_ptk p ON m.ptk_id = p.id WHERE p.jenis_ptk != 'Guru Mata Pelajaran' LIMIT 5");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
