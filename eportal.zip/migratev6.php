<?php
/**
 * Migration v6 - E-Performance Manual Input
 */
require_once __DIR__ . '/api/config.php';

$pdo = db();

echo "<h3>Migration V6 - E-Performance Manual Input</h3><pre>";

$queries = [
    "CREATE TABLE IF NOT EXISTS `perf_penilaian_manual` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `periode_id` int(11) NOT NULL,
      `ptk_id` int(11) NOT NULL,
      `data` longtext DEFAULT NULL,
      `created_at` datetime DEFAULT current_timestamp(),
      `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
      PRIMARY KEY (`id`),
      UNIQUE KEY `uk_periode_ptk` (`periode_id`, `ptk_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;"
];

foreach ($queries as $sql) {
    try {
        $pdo->exec($sql);
        echo "[OK] Table perf_penilaian_manual structure verified.\n";
    } catch (Exception $e) {
        echo "[ERR] " . $e->getMessage() . "\n";
    }
}

echo "\nMigration Complete.";
echo "</pre>";
