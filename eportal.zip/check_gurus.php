<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$periode_id = 6;
$stmtR = $db->prepare("SELECT jenis_penilai FROM perf_jenis_penilai WHERE periode_id = ?");
$stmtR->execute([$periode_id]);
$roles = $stmtR->fetchAll(PDO::FETCH_COLUMN);

foreach ($roles as $role) {
    if (strtolower($role) === 'siswa') continue;
    
    $role_fallback = (stripos($role, 'Guru') !== false || stripos($role, 'Wali Kelas') !== false) ? 'Guru' : $role;
    $stmtU = $db->prepare("SELECT id as portal_id, username, nama_lengkap as nama FROM users WHERE tupoksi = ? AND status = 1");
    $stmtU->execute([$role]);
    $users = $stmtU->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($users as $u) {
        $total_expected = 0;
        $rater_str = $role;
        $rater_fallback = (stripos($role, 'Guru') !== false || stripos($role, 'Wali Kelas') !== false) ? 'Guru' : $role;
        
        // 1. Diri Sendiri
        $stmtSelf = $db->prepare("
            SELECT COUNT(id) FROM perf_instrumen WHERE periode_id = ? AND is_manual = 0 AND (
                (
                    (FIND_IN_SET(?, target_jabatan) > 0 OR FIND_IN_SET(?, target_jabatan) > 0)
                    AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0)
                )
                OR
                (
                    FIND_IN_SET('Diri Sendiri', target_jabatan) > 0 
                    AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0 OR FIND_IN_SET('Diri Sendiri', target_dinilai) > 0)
                )
                OR
                (FIND_IN_SET(?, target_jabatan) > 0 AND FIND_IN_SET('Diri Sendiri', target_dinilai) > 0)
            )
        ");
        $stmtSelf->execute([
            $periode_id, 
            $rater_str, $rater_fallback, $role,
            $role,
            $role
        ]);
        $total_expected += (int)$stmtSelf->fetchColumn();
        
        // 2. Teman Sejawat
        $stmtPeerList = $db->prepare("SELECT p.jenis_ptk FROM perf_penugasan_sejawat ps JOIN perf_ptk p ON p.id = ps.dinilai_ptk_id WHERE ps.penilai_ptk_id = (SELECT id FROM perf_ptk WHERE niy = ? LIMIT 1) AND ps.periode_id = ?");
        $stmtPeerList->execute([$u['username'], $periode_id]);
        $peers = $stmtPeerList->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($peers as $peer) {
            $stmtPeerQ = $db->prepare("
                SELECT COUNT(id) FROM perf_instrumen WHERE periode_id = ? AND is_manual = 0 AND (
                    (
                        (FIND_IN_SET(?, target_jabatan) > 0 OR FIND_IN_SET(?, target_jabatan) > 0)
                        AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0)
                    )
                    OR
                    (
                        FIND_IN_SET('Teman Sejawat', target_jabatan) > 0 
                        AND (target_dinilai = 'Semua' OR FIND_IN_SET(?, target_dinilai) > 0 OR FIND_IN_SET('Teman Sejawat', target_dinilai) > 0)
                    )
                    OR
                    (FIND_IN_SET(?, target_jabatan) > 0 AND FIND_IN_SET('Teman Sejawat', target_dinilai) > 0)
                )
            ");
            $stmtPeerQ->execute([
                $periode_id, 
                $rater_str, $rater_fallback, $peer['jenis_ptk'],
                $peer['jenis_ptk'],
                $peer['jenis_ptk']
            ]);
            $total_expected += (int)$stmtPeerQ->fetchColumn();
        }
        
        if ($total_expected === 0) $total_expected = 1;

        $stmtPU = $db->prepare("SELECT id FROM perf_users WHERE username = ? LIMIT 1");
        $stmtPU->execute([$u['username']]);
        $perfUser = $stmtPU->fetch(PDO::FETCH_ASSOC);
        
        $answered = 0;
        if ($perfUser) {
            $perf_user_id = $perfUser['id'];
            $stmtAns = $db->prepare("SELECT COUNT(*) FROM perf_penilaian WHERE penilai_id = ? AND periode_id = ?");
            $stmtAns->execute([$perf_user_id, $periode_id]);
            $answered = (int)$stmtAns->fetchColumn();
        }
        
        $perc = round(($answered / $total_expected) * 100);
        if ($perc != 100) {
             echo $u['nama'] . " - Answered: $answered, Expected: $total_expected, Perc: $perc%\n";
        }
    }
}
?>
