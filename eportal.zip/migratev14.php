<?php
/**
 * Migration V14: Cleanup Orphaned Data e-Performance
 * Membersihkan data penilaian gaib/nyangkut (periode_id = 0) 
 * akibat bug tombol Terapkan versi sebelumnya.
 */

require_once __DIR__ . '/api/config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $db = db();
    
    echo "<h2>Memulai Pembersihan Data Penilaian e-Performance</h2>";
    echo "<pre>";
    
    // Check if the table exists first to avoid errors on completely fresh installs
    $stmtCheck = $db->query("SHOW TABLES LIKE 'perf_penilaian'");
    if ($stmtCheck->rowCount() > 0) {
        $db->beginTransaction();
        
        $stmt = $db->query("DELETE FROM perf_penilaian WHERE periode_id = 0");
        $deleted = $stmt->rowCount();
        
        $db->commit();
        
        echo "[SUKSES] Berhasil membersihkan $deleted baris data gaib/nyangkut (periode_id = 0).\n";
    } else {
        echo "[INFO] Tabel perf_penilaian belum ada, skip pembersihan.\n";
    }
    
    echo "</pre>";
    echo "<h3 style='color:green;'>Selesai! Silakan cek kembali fitur hapus pertanyaannya.</h3>";
    
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    echo "<h3 style='color:red;'>Terjadi Kesalahan:</h3>";
    echo "<pre>" . $e->getMessage() . "</pre>";
}
?>
