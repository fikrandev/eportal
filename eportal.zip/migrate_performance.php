<?php
require_once __DIR__ . '/api/config.php';

try {
    $sql = file_get_contents(__DIR__ . '/database/e_performance.sql');
    if (!$sql) {
        die("Gagal membaca file database/e_performance.sql");
    }

    // Eksekusi semua query
    $pdo = db();
    $pdo->exec($sql);
    
    echo "<h1>Migrasi Berhasil!</h1>";
    echo "<p>Tabel-tabel E-Performance berhasil ditambahkan tanpa mengganggu data yang sudah ada.</p>";
    echo "<p>Silakan hapus file ini demi keamanan.</p>";
} catch (PDOException $e) {
    echo "<h1>Terjadi Kesalahan</h1>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
}
