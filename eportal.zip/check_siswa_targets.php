<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT target_dinilai FROM perf_instrumen WHERE is_manual=0 AND target_jabatan LIKE '%Siswa%' GROUP BY target_dinilai");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
