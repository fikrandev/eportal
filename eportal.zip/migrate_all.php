<?php
/**
 * ============================================================
 *  E-Portal — MIGRATE ALL (Global Schema Synchronizer)
 * ============================================================
 *  
 *  Satu file untuk menyamakan SELURUH schema database
 *  antara local dan hosting TANPA menghapus data.
 * 
 *  Apa yang dilakukan:
 *   ✅ CREATE TABLE IF NOT EXISTS — buat tabel baru
 *   ✅ ADD COLUMN — tambah kolom yang belum ada
 *   ✅ MODIFY COLUMN — ubah tipe kolom yang berbeda
 *   ✅ ADD INDEX/UNIQUE — tambah index yang belum ada
 *   ✅ Seed data default (modules, referensi)
 *   ❌ TIDAK menghapus tabel, kolom, atau data apapun
 * 
 *  Idempotent: Aman dijalankan berulang kali.
 * 
 *  Cara pakai:
 *   1. Upload file ini ke root eportal di hosting
 *   2. Buka: https://domain.com/migrate_all.php
 *   3. Setelah selesai, HAPUS file ini demi keamanan
 * 
 *  Consolidated from: migrate.php, migratev4-v7.php,
 *    modules/e-sarpras/migrate.php, modules/e-xam-card/migrate.php,
 *    database/e_performance.sql, database/e_schedule.sql,
 *    run_db.php, modules/e-graduation/migrate_rata_rata.php
 * ============================================================
 */

// Prevent timeout for large databases
set_time_limit(300);
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/api/config.php';

// ============================================================
// STATISTICS TRACKER
// ============================================================
$stats = [
    'tables_created'  => 0,
    'tables_skipped'  => 0,
    'columns_added'   => 0,
    'columns_modified'=> 0,
    'columns_skipped' => 0,
    'indexes_added'   => 0,
    'indexes_skipped' => 0,
    'seeds_applied'   => 0,
    'errors'          => 0,
];

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Portal — Migrate All</title>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            padding: 24px;
        }
        .container {
            max-width: 960px;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            padding: 32px 0 24px;
        }
        .header h1 {
            font-size: 28px;
            background: linear-gradient(135deg, #38bdf8, #818cf8, #c084fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }
        .header p { color: #94a3b8; font-size: 14px; }
        .log-container {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 20px;
            margin: 16px 0;
            overflow: auto;
            max-height: 70vh;
        }
        .log {
            font-family: 'JetBrains Mono', monospace;
            font-size: 12.5px;
            line-height: 1.7;
            white-space: pre-wrap;
            word-break: break-all;
        }
        .section-title {
            color: #38bdf8;
            font-weight: 600;
            font-size: 14px;
            display: block;
            margin: 16px 0 4px;
            padding: 4px 0;
            border-bottom: 1px solid #334155;
        }
        .ok { color: #4ade80; }
        .skip { color: #94a3b8; }
        .err { color: #f87171; }
        .warn { color: #fbbf24; }
        .info { color: #60a5fa; }
        .mod { color: #c084fc; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 12px;
            margin: 20px 0;
        }
        .stat-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 10px;
            padding: 16px;
            text-align: center;
        }
        .stat-card .value {
            font-size: 28px;
            font-weight: 700;
            font-family: 'JetBrains Mono', monospace;
        }
        .stat-card .label {
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
        }
        .stat-card.green .value { color: #4ade80; }
        .stat-card.blue .value { color: #60a5fa; }
        .stat-card.purple .value { color: #c084fc; }
        .stat-card.yellow .value { color: #fbbf24; }
        .stat-card.red .value { color: #f87171; }
        .stat-card.gray .value { color: #94a3b8; }
        .btn-back {
            display: inline-block;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            color: white;
            padding: 12px 32px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            margin-top: 16px;
            transition: all .2s;
        }
        .btn-back:hover { transform: translateY(-2px); box-shadow: 0 4px 20px rgba(59,130,246,.4); }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>⚡ E-Portal — Migrate All</h1>
        <p>Global Schema Synchronizer • Tanpa Menghapus Data</p>
    </div>
    <div class="log-container">
        <div class="log">
<?php

// Flush output progressively
ob_implicit_flush(true);
if (ob_get_level()) ob_end_flush();

$pdo = db();

// ============================================================
// HELPER FUNCTIONS
// ============================================================

function out($class, $prefix, $msg) {
    echo "<span class=\"$class\">[$prefix]</span> $msg\n";
    if (function_exists('ob_flush')) { @ob_flush(); }
    @flush();
}

function safeExec($sql, $desc = '') {
    global $pdo, $stats;
    try {
        $pdo->exec($sql);
        return true;
    } catch (PDOException $e) {
        out('err', 'ERR', "$desc: " . htmlspecialchars($e->getMessage()));
        $stats['errors']++;
        return false;
    }
}

/**
 * Ensure a table exists. Uses CREATE TABLE IF NOT EXISTS.
 */
function ensureTable($tableName, $createSQL) {
    global $pdo, $stats;
    try {
        // Check if table already exists
        $check = $pdo->query("SHOW TABLES LIKE '$tableName'")->fetch();
        if ($check) {
            out('skip', 'SKIP', "Table `$tableName` already exists");
            $stats['tables_skipped']++;
        } else {
            $pdo->exec($createSQL);
            out('ok', 'CREATE', "Table `$tableName` created ✓");
            $stats['tables_created']++;
        }
        return true;
    } catch (PDOException $e) {
        out('err', 'ERR', "Table `$tableName`: " . htmlspecialchars($e->getMessage()));
        $stats['errors']++;
        return false;
    }
}

/**
 * Ensure a column exists in a table. Add if missing, optionally modify type.
 */
function ensureColumn($table, $column, $definition, $afterCol = null) {
    global $pdo, $stats;
    try {
        $check = $pdo->query("SHOW TABLES LIKE '$table'")->fetch();
        if (!$check) {
            out('skip', 'SKIP', "Table `$table` does not exist, skipping column `$column`");
            return false;
        }

        $stmt = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
        $existing = $stmt->fetch();

        $afterClause = $afterCol ? " AFTER `$afterCol`" : '';

        if (!$existing) {
            $sql = "ALTER TABLE `$table` ADD COLUMN `$column` $definition$afterClause";
            $pdo->exec($sql);
            out('ok', 'ADD', "Column `$table`.`$column` added ✓");
            $stats['columns_added']++;
            return true;
        } else {
            $stats['columns_skipped']++;
            return true;
        }
    } catch (PDOException $e) {
        out('err', 'ERR', "Column `$table`.`$column`: " . htmlspecialchars($e->getMessage()));
        $stats['errors']++;
        return false;
    }
}

/**
 * Modify an existing column's type/definition.
 */
function modifyColumn($table, $column, $newDefinition) {
    global $pdo, $stats;
    try {
        $check = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'")->fetch();
        if (!$check) {
            out('skip', 'SKIP', "Column `$table`.`$column` does not exist, cannot modify");
            return false;
        }
        $pdo->exec("ALTER TABLE `$table` MODIFY COLUMN `$column` $newDefinition");
        out('mod', 'MODIFY', "Column `$table`.`$column` modified ✓");
        $stats['columns_modified']++;
        return true;
    } catch (PDOException $e) {
        out('err', 'ERR', "Modify `$table`.`$column`: " . htmlspecialchars($e->getMessage()));
        $stats['errors']++;
        return false;
    }
}

/**
 * Ensure an index exists on a table.
 */
function ensureIndex($table, $indexName, $indexSQL) {
    global $pdo, $stats;
    try {
        $check = $pdo->query("SHOW TABLES LIKE '$table'")->fetch();
        if (!$check) return false;

        $indexes = $pdo->query("SHOW INDEX FROM `$table` WHERE Key_name = '$indexName'")->fetchAll();
        if (!empty($indexes)) {
            $stats['indexes_skipped']++;
            return true;
        }
        $pdo->exec("ALTER TABLE `$table` $indexSQL");
        out('ok', 'INDEX', "Index `$indexName` on `$table` added ✓");
        $stats['indexes_added']++;
        return true;
    } catch (PDOException $e) {
        // Might fail if duplicate key name - that's OK
        $stats['indexes_skipped']++;
        return true;
    }
}

// ============================================================
// SECTION 1: CORE SYSTEM TABLES
// ============================================================
echo "<span class=\"section-title\">📋 1. CORE SYSTEM TABLES</span>\n";

ensureTable('users', "CREATE TABLE IF NOT EXISTS `users` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `nama_lengkap` VARCHAR(100) NOT NULL,
    `role` ENUM('superadmin','user','guru') NOT NULL DEFAULT 'user',
    `tempat_lahir` VARCHAR(100) DEFAULT NULL,
    `tgl_lahir` DATE DEFAULT NULL,
    `tupoksi` VARCHAR(150) DEFAULT NULL,
    `jabatan` VARCHAR(150) DEFAULT NULL,
    `status_guru` VARCHAR(100) DEFAULT NULL,
    `tpg` ENUM('Ya','Tidak') NOT NULL DEFAULT 'Tidak',
    `tmt` DATE DEFAULT NULL,
    `avatar` VARCHAR(255) DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=inactive',
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('modules', "CREATE TABLE IF NOT EXISTS `modules` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama_modul` VARCHAR(100) NOT NULL,
    `slug` VARCHAR(100) NOT NULL,
    `deskripsi` TEXT DEFAULT NULL,
    `icon_svg` TEXT NOT NULL,
    `url_path` VARCHAR(255) NOT NULL,
    `color` VARCHAR(20) DEFAULT '#1565C0',
    `urutan` INT(11) NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('settings', "CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `setting_key` VARCHAR(100) NOT NULL,
    `setting_value` TEXT DEFAULT NULL,
    `setting_type` ENUM('text','number','boolean','json','file') NOT NULL DEFAULT 'text',
    `keterangan` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sessions', "CREATE TABLE IF NOT EXISTS `sessions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `expired_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_token` (`token`),
    CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('academic_years', "CREATE TABLE IF NOT EXISTS `academic_years` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `tahun_ajaran` VARCHAR(9) NOT NULL,
    `semester` ENUM('1','2') NOT NULL DEFAULT '1',
    `tanggal_mulai` DATE DEFAULT NULL,
    `tanggal_selesai` DATE DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_academic_year_semester` (`tahun_ajaran`, `semester`),
    KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('students', "CREATE TABLE IF NOT EXISTS `students` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `no_urut` INT(11) DEFAULT 0,
    `nis` VARCHAR(50) NOT NULL,
    `nisn` VARCHAR(50) DEFAULT NULL,
    `nama` VARCHAR(150) NOT NULL,
    `tempat_lahir` VARCHAR(100) DEFAULT NULL,
    `jenis_kelamin` ENUM('L','P') NOT NULL,
    `tanggal_lahir` DATE NOT NULL,
    `kelas` VARCHAR(50) NOT NULL,
    `foto_path` VARCHAR(255) DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `rata_rata` DECIMAL(5,2) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_student_nis_year` (`academic_year_id`, `nis`),
    UNIQUE KEY `uk_student_nisn_year` (`academic_year_id`, `nisn`),
    KEY `idx_student_class` (`kelas`),
    CONSTRAINT `fk_students_academic_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Core column evolutions
echo "\n";
ensureColumn('users', 'tempat_lahir', "VARCHAR(100) DEFAULT NULL", 'nama_lengkap');
ensureColumn('users', 'tgl_lahir', "DATE DEFAULT NULL", 'tempat_lahir');
ensureColumn('users', 'tupoksi', "VARCHAR(150) DEFAULT NULL", 'tgl_lahir');
ensureColumn('users', 'jabatan', "VARCHAR(150) DEFAULT NULL", 'tupoksi');
ensureColumn('users', 'status_guru', "VARCHAR(100) DEFAULT NULL", 'jabatan');
ensureColumn('users', 'tpg', "ENUM('Ya','Tidak') NOT NULL DEFAULT 'Tidak'", 'status_guru');
ensureColumn('users', 'tmt', "DATE DEFAULT NULL", 'tpg');
ensureColumn('students', 'tempat_lahir', "VARCHAR(100) DEFAULT NULL", 'nama');
ensureColumn('students', 'rata_rata', "DECIMAL(5,2) DEFAULT NULL", 'status');

// ============================================================
// SECTION 2: E-SCHEDULE MODULE TABLES (7 tables)
// ============================================================
echo "\n<span class=\"section-title\">📅 2. E-SCHEDULE MODULE (7 tables)</span>\n";

ensureTable('sch_jam_belajar', "CREATE TABLE IF NOT EXISTS `sch_jam_belajar` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `hari` VARCHAR(20) NOT NULL,
    `jam_ke` INT(11) NOT NULL,
    `tipe` ENUM('Pembelajaran', 'Istirahat', 'Upacara', 'Pembiasaan') NOT NULL DEFAULT 'Pembelajaran',
    `nama_jam` VARCHAR(50) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_hari_jam` (`hari`, `jam_ke`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sch_mapel', "CREATE TABLE IF NOT EXISTS `sch_mapel` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `kode_mapel` VARCHAR(50) NOT NULL,
    `nama_mapel` VARCHAR(150) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kode_mapel` (`kode_mapel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sch_kelas', "CREATE TABLE IF NOT EXISTS `sch_kelas` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `rombel` INT(11) NOT NULL,
    `nama_kelas` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_nama_kelas` (`nama_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sch_guru', "CREATE TABLE IF NOT EXISTS `sch_guru` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `kode_guru` VARCHAR(50) NOT NULL,
    `nama_guru` VARCHAR(150) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kode_guru` (`kode_guru`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sch_distribusi', "CREATE TABLE IF NOT EXISTS `sch_distribusi` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `guru_id` INT(11) UNSIGNED NOT NULL,
    `kelas_id` INT(11) UNSIGNED NOT NULL,
    `mapel_id` INT(11) UNSIGNED NOT NULL,
    `jp` INT(11) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_guru` (`guru_id`),
    KEY `idx_kelas` (`kelas_id`),
    KEY `idx_mapel` (`mapel_id`),
    CONSTRAINT `fk_dist_guru` FOREIGN KEY (`guru_id`) REFERENCES `sch_guru` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_dist_kelas` FOREIGN KEY (`kelas_id`) REFERENCES `sch_kelas` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_dist_mapel` FOREIGN KEY (`mapel_id`) REFERENCES `sch_mapel` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Bug Fix: sch_kesediaan was MISSING from master migrate.php!
ensureTable('sch_kesediaan', "CREATE TABLE IF NOT EXISTS `sch_kesediaan` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `guru_id` INT(11) UNSIGNED NOT NULL,
    `jam_belajar_id` INT(11) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_guru_jam` (`guru_id`, `jam_belajar_id`),
    CONSTRAINT `fk_kes_guru` FOREIGN KEY (`guru_id`) REFERENCES `sch_guru` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_kes_jam` FOREIGN KEY (`jam_belajar_id`) REFERENCES `sch_jam_belajar` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sch_jadwal', "CREATE TABLE IF NOT EXISTS `sch_jadwal` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `kelas_id` INT(11) UNSIGNED NOT NULL,
    `jam_belajar_id` INT(11) UNSIGNED NOT NULL,
    `distribusi_id` INT(11) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kelas_jam` (`kelas_id`, `jam_belajar_id`),
    CONSTRAINT `fk_jadwal_kelas` FOREIGN KEY (`kelas_id`) REFERENCES `sch_kelas` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_jadwal_jam` FOREIGN KEY (`jam_belajar_id`) REFERENCES `sch_jam_belajar` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_jadwal_dist` FOREIGN KEY (`distribusi_id`) REFERENCES `sch_distribusi` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Schedule column evolutions
ensureColumn('sch_jam_belajar', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sch_jam_belajar', 'updated_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
ensureColumn('sch_mapel', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sch_mapel', 'updated_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
ensureColumn('sch_kelas', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sch_kelas', 'updated_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
ensureColumn('sch_guru', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sch_guru', 'updated_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
ensureColumn('sch_distribusi', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sch_distribusi', 'updated_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

// ============================================================
// SECTION 3: E-GRADUATION MODULE TABLES (8 tables)
// ============================================================
echo "\n<span class=\"section-title\">🎓 3. E-GRADUATION MODULE (8 tables)</span>\n";

ensureTable('grad_subject_groups', "CREATE TABLE IF NOT EXISTS `grad_subject_groups` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `kode` VARCHAR(20) NOT NULL,
    `nama` VARCHAR(150) NOT NULL,
    `tipe` ENUM('wajib','pilihan','lainnya') NOT NULL DEFAULT 'wajib',
    `deskripsi` TEXT DEFAULT NULL,
    `urutan` INT(11) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_group_year_code` (`academic_year_id`, `kode`),
    KEY `idx_grad_group_year` (`academic_year_id`),
    CONSTRAINT `fk_grad_group_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_subjects', "CREATE TABLE IF NOT EXISTS `grad_subjects` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `group_id` INT(11) UNSIGNED NOT NULL,
    `kode_mapel` VARCHAR(50) DEFAULT NULL,
    `nama_mapel` VARCHAR(150) NOT NULL,
    `kelas` VARCHAR(100) DEFAULT NULL,
    `urutan` INT(11) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_subject_scope` (`academic_year_id`, `group_id`, `kelas`, `nama_mapel`),
    KEY `idx_grad_subject_year` (`academic_year_id`),
    KEY `idx_grad_subject_group` (`group_id`),
    KEY `idx_grad_subject_class` (`kelas`),
    CONSTRAINT `fk_grad_subject_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_grad_subject_group` FOREIGN KEY (`group_id`) REFERENCES `grad_subject_groups`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_letter_settings', "CREATE TABLE IF NOT EXISTS `grad_letter_settings` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `start_number` INT(11) NOT NULL DEFAULT 1,
    `total` INT(11) NOT NULL DEFAULT 0,
    `letter_format` VARCHAR(255) NOT NULL,
    `graduation_date` DATE DEFAULT NULL,
    `signing_date` DATE DEFAULT NULL,
    `headmaster_user_id` INT(11) UNSIGNED DEFAULT NULL,
    `headmaster_name` VARCHAR(150) DEFAULT NULL,
    `headmaster_niy` VARCHAR(50) DEFAULT NULL,
    `headmaster_position` VARCHAR(100) NOT NULL DEFAULT 'Kepala Sekolah',
    `kop_image` VARCHAR(255) DEFAULT NULL,
    `decision_number` VARCHAR(100) DEFAULT NULL,
    `decision_date` DATE DEFAULT NULL,
    `decision_about` VARCHAR(255) DEFAULT NULL,
    `skl_city` VARCHAR(100) DEFAULT NULL,
    `announcement_status` VARCHAR(20) NOT NULL DEFAULT 'not_set',
    `announcement_at` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_letter_year` (`academic_year_id`),
    KEY `idx_grad_letter_headmaster` (`headmaster_user_id`),
    CONSTRAINT `fk_grad_letter_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_grad_letter_headmaster` FOREIGN KEY (`headmaster_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_student_letters', "CREATE TABLE IF NOT EXISTS `grad_student_letters` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `student_id` INT(11) UNSIGNED NOT NULL,
    `sequence_no` INT(11) NOT NULL,
    `letter_number` VARCHAR(255) NOT NULL,
    `graduation_date` DATE DEFAULT NULL,
    `signing_date` DATE DEFAULT NULL,
    `headmaster_name` VARCHAR(150) DEFAULT NULL,
    `headmaster_niy` VARCHAR(50) DEFAULT NULL,
    `headmaster_position` VARCHAR(100) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_student_letter` (`academic_year_id`, `student_id`),
    UNIQUE KEY `uk_grad_sequence_letter` (`academic_year_id`, `sequence_no`),
    KEY `idx_grad_student_letter_year` (`academic_year_id`),
    CONSTRAINT `fk_grad_student_letter_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_grad_student_letter_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_student_scores', "CREATE TABLE IF NOT EXISTS `grad_student_scores` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `student_id` INT(11) UNSIGNED NOT NULL,
    `subject_id` INT(11) UNSIGNED NOT NULL,
    `nilai_akhir` DECIMAL(5,2) DEFAULT NULL,
    `predikat` VARCHAR(10) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_score_student_subject` (`academic_year_id`, `student_id`, `subject_id`),
    KEY `idx_grad_score_year` (`academic_year_id`),
    KEY `idx_grad_score_subject` (`subject_id`),
    CONSTRAINT `fk_grad_score_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_grad_score_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_grad_score_subject` FOREIGN KEY (`subject_id`) REFERENCES `grad_subjects`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_teacher_access', "CREATE TABLE IF NOT EXISTS `grad_teacher_access` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `access_role` ENUM('wali_kelas') NOT NULL DEFAULT 'wali_kelas',
    `kelas` VARCHAR(100) NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_access_user` (`user_id`),
    KEY `idx_grad_access_class` (`kelas`),
    CONSTRAINT `fk_grad_access_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_student_accounts', "CREATE TABLE IF NOT EXISTS `grad_student_accounts` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `student_id` INT(11) UNSIGNED NOT NULL,
    `username` VARCHAR(50) NOT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `generated_at` DATETIME DEFAULT NULL,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_student_account` (`academic_year_id`, `student_id`),
    UNIQUE KEY `uk_grad_student_username` (`academic_year_id`, `username`),
    KEY `idx_grad_student_account_year` (`academic_year_id`),
    CONSTRAINT `fk_grad_student_account_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_grad_student_account_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('grad_student_sessions', "CREATE TABLE IF NOT EXISTS `grad_student_sessions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `account_id` INT(11) UNSIGNED NOT NULL,
    `token` VARCHAR(100) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `expired_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_grad_student_session_token` (`token`),
    KEY `idx_grad_student_session_account` (`account_id`),
    CONSTRAINT `fk_grad_student_session_account` FOREIGN KEY (`account_id`) REFERENCES `grad_student_accounts`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Graduation column evolutions
ensureColumn('grad_letter_settings', 'kop_image', "VARCHAR(255) DEFAULT NULL", 'headmaster_position');
ensureColumn('grad_letter_settings', 'decision_number', "VARCHAR(100) DEFAULT NULL", 'kop_image');
ensureColumn('grad_letter_settings', 'decision_date', "DATE DEFAULT NULL", 'decision_number');
ensureColumn('grad_letter_settings', 'decision_about', "VARCHAR(255) DEFAULT NULL", 'decision_date');
ensureColumn('grad_letter_settings', 'skl_city', "VARCHAR(100) DEFAULT NULL", 'decision_about');
ensureColumn('grad_letter_settings', 'announcement_status', "VARCHAR(20) NOT NULL DEFAULT 'not_set'", 'skl_city');
ensureColumn('grad_letter_settings', 'announcement_at', "DATETIME DEFAULT NULL", 'announcement_status');

// ============================================================
// SECTION 4: E-SARPRAS MODULE TABLES (16 tables)
// ============================================================
echo "\n<span class=\"section-title\">🏗️ 4. E-SARPRAS MODULE (16 tables)</span>\n";

ensureTable('kategori_sarpras', "CREATE TABLE IF NOT EXISTS `kategori_sarpras` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama` VARCHAR(100) NOT NULL,
    `kode` VARCHAR(10) NOT NULL,
    `jenis` ENUM('sarana', 'prasarana') NOT NULL DEFAULT 'sarana',
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kode` (`kode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('tanah', "CREATE TABLE IF NOT EXISTS `tanah` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama` VARCHAR(150) NOT NULL,
    `kode_tanah` VARCHAR(50) DEFAULT NULL,
    `lokasi` TEXT DEFAULT NULL,
    `lintang` VARCHAR(50) DEFAULT NULL,
    `bujur` VARCHAR(50) DEFAULT NULL,
    `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `no_sertifikat` VARCHAR(100) DEFAULT NULL,
    `tgl_sertifikat` DATE DEFAULT NULL,
    `kepemilikan` VARCHAR(50) DEFAULT 'Milik Sendiri',
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('bangunan', "CREATE TABLE IF NOT EXISTS `bangunan` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `tanah_id` INT(11) UNSIGNED NOT NULL,
    `nama` VARCHAR(150) NOT NULL,
    `kode_bangunan` VARCHAR(50) DEFAULT NULL,
    `luas_m2` DECIMAL(10,2) NOT NULL DEFAULT 0,
    `tahun_perolehan` YEAR DEFAULT NULL,
    `keterangan` TEXT DEFAULT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_bang_tanah` FOREIGN KEY (`tanah_id`) REFERENCES `tanah`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('ruang', "CREATE TABLE IF NOT EXISTS `ruang` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `bangunan_id` INT(11) UNSIGNED NOT NULL,
    `pj_id` INT(11) UNSIGNED DEFAULT NULL,
    `nama` VARCHAR(100) NOT NULL,
    `kode_ruang` VARCHAR(20) NOT NULL,
    `panjang_m` DECIMAL(10,2) DEFAULT NULL,
    `lebar_m` DECIMAL(10,2) DEFAULT NULL,
    `luas_m2` DECIMAL(10,2) DEFAULT NULL,
    `luas_plester_m2` DECIMAL(10,2) DEFAULT NULL,
    `lantai_ke` INT(11) DEFAULT 1,
    `kapasitas` INT(11) DEFAULT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kode_ruang` (`kode_ruang`),
    CONSTRAINT `fk_ruang_bang` FOREIGN KEY (`bangunan_id`) REFERENCES `bangunan`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras', "CREATE TABLE IF NOT EXISTS `sarpras` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `ruang_id` INT(11) UNSIGNED NOT NULL,
    `kategori_id` INT(11) UNSIGNED NOT NULL,
    `bk_id` INT NULL COMMENT 'Ref to Book Classification',
    `nama` VARCHAR(200) NOT NULL,
    `kode_inventaris` VARCHAR(50) NOT NULL,
    `merk` VARCHAR(100) DEFAULT NULL,
    `spesifikasi` TEXT DEFAULT NULL,
    `satuan` VARCHAR(50) DEFAULT 'Unit',
    `jumlah` INT(11) NOT NULL DEFAULT 1,
    `harga_perolehan` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `tahun_perolehan` YEAR NOT NULL,
    `sumber_dana` VARCHAR(50) DEFAULT 'BOS',
    `kepemilikan` VARCHAR(50) DEFAULT 'Milik Sendiri',
    `jenis_sarana` VARCHAR(100) DEFAULT NULL,
    `no_polisi` VARCHAR(20) DEFAULT NULL,
    `no_bpkb` VARCHAR(30) DEFAULT NULL,
    `alamat` TEXT DEFAULT NULL,
    `kondisi_baik` INT(11) NOT NULL DEFAULT 0,
    `kondisi_rusak_ringan` INT(11) NOT NULL DEFAULT 0,
    `kondisi_rusak_berat` INT(11) NOT NULL DEFAULT 0,
    `keterangan` TEXT DEFAULT NULL,
    `grup_pintasan` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_kode_inv` (`kode_inventaris`),
    CONSTRAINT `fk_s_ruang` FOREIGN KEY (`ruang_id`) REFERENCES `ruang`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_foto', "CREATE TABLE IF NOT EXISTS `sarpras_foto` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `sarpras_id` INT(11) UNSIGNED NOT NULL,
    `foto_path` VARCHAR(255) NOT NULL,
    `keterangan` VARCHAR(255) DEFAULT NULL,
    `urutan` INT DEFAULT 0,
    CONSTRAINT `fk_foto_sarpras` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_periodik', "CREATE TABLE IF NOT EXISTS `sarpras_periodik` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `sarpras_id` INT(11) UNSIGNED NOT NULL,
    `periode` VARCHAR(20) DEFAULT NULL,
    `tahun` YEAR DEFAULT NULL,
    `kondisi_baik` INT DEFAULT NULL,
    `kondisi_rusak_ringan` INT DEFAULT NULL,
    `kondisi_rusak_berat` INT DEFAULT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `updated_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_berita_acara', "CREATE TABLE IF NOT EXISTS `sarpras_berita_acara` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nomor_ba` VARCHAR(100) NOT NULL,
    `tanggal_ba` DATE NOT NULL,
    `tahun_ba` YEAR DEFAULT NULL,
    `file_ba` VARCHAR(255) DEFAULT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_perbaikan', "CREATE TABLE IF NOT EXISTS `sarpras_perbaikan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `sarpras_id` INT(11) UNSIGNED NOT NULL,
    `berita_acara_id` INT NULL,
    `tanggal` DATE DEFAULT NULL,
    `tanggal_selesai` DATE DEFAULT NULL,
    `biaya` DECIMAL(15,2) DEFAULT 0,
    `jumlah` INT DEFAULT 1,
    `deskripsi` TEXT DEFAULT NULL,
    `status` ENUM('Diajukan', 'Proses', 'Selesai', 'Batal', 'Penghapusan') DEFAULT 'Diajukan',
    `updated_by` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_perb_sarpras` FOREIGN KEY (`sarpras_id`) REFERENCES `sarpras`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_pj', "CREATE TABLE IF NOT EXISTS `sarpras_pj` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `bangunan_id` INT(11) UNSIGNED NULL,
    `user_id` INT NULL,
    `nama` VARCHAR(150) DEFAULT NULL,
    `nip` VARCHAR(50) DEFAULT NULL,
    `jabatan` VARCHAR(100) DEFAULT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_peminjaman', "CREATE TABLE IF NOT EXISTS `sarpras_peminjaman` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NULL,
    `nama_peminjam` VARCHAR(255) NOT NULL,
    `jabatan` VARCHAR(255) DEFAULT NULL,
    `no_hp` VARCHAR(50) DEFAULT NULL,
    `asal_unit` VARCHAR(150) DEFAULT NULL,
    `nama_kegiatan` VARCHAR(255) DEFAULT NULL,
    `sarpras_id` INT(11) UNSIGNED NOT NULL,
    `jumlah` INT DEFAULT 1,
    `kondisi_sebelum` TEXT DEFAULT NULL,
    `kondisi_sesudah` TEXT DEFAULT NULL,
    `tanggal_pinjam` DATE NOT NULL,
    `tanggal_kembali_rencana` DATE DEFAULT NULL,
    `tanggal_kembali_aktual` DATE DEFAULT NULL,
    `status` ENUM('Dipinjam', 'Dikembalikan') DEFAULT 'Dipinjam',
    `catatan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_by` INT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_roles_def', "CREATE TABLE IF NOT EXISTS `sarpras_roles_def` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(100) NOT NULL,
    `deskripsi` TEXT DEFAULT NULL,
    `is_locked` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_role_permissions', "CREATE TABLE IF NOT EXISTS `sarpras_role_permissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT NOT NULL,
    `permission_key` VARCHAR(100) NOT NULL,
    UNIQUE KEY `uk_role_perm` (`role_id`, `permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_roles', "CREATE TABLE IF NOT EXISTS `sarpras_roles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `custom_role_id` INT NULL,
    `role` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sarpras_referensi', "CREATE TABLE IF NOT EXISTS `sarpras_referensi` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `kategori` VARCHAR(50) NOT NULL,
    `kode` VARCHAR(50) DEFAULT NULL,
    `nama` VARCHAR(100) NOT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_kategori` (`kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('sequence_tracker', "CREATE TABLE IF NOT EXISTS `sequence_tracker` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `kategori_kode` VARCHAR(10) DEFAULT NULL,
    `tahun` YEAR DEFAULT NULL,
    `last_seq` INT DEFAULT 0,
    UNIQUE KEY `uk_seq` (`kategori_kode`, `tahun`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Sarpras column evolutions (ensure all columns exist even if table was created by old migration)
echo "\n";
ensureColumn('tanah', 'lintang', "VARCHAR(50) DEFAULT NULL", 'lokasi');
ensureColumn('tanah', 'bujur', "VARCHAR(50) DEFAULT NULL", 'lintang');
ensureColumn('tanah', 'tgl_sertifikat', "DATE DEFAULT NULL", 'no_sertifikat');
ensureColumn('tanah', 'keterangan', "TEXT DEFAULT NULL", 'kepemilikan');
ensureColumn('tanah', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");

ensureColumn('bangunan', 'tahun_perolehan', "YEAR DEFAULT NULL", 'luas_m2');
ensureColumn('bangunan', 'keterangan', "TEXT DEFAULT NULL", 'tahun_perolehan');

ensureColumn('ruang', 'pj_id', "INT(11) UNSIGNED DEFAULT NULL", 'bangunan_id');
ensureColumn('ruang', 'luas_plester_m2', "DECIMAL(10,2) DEFAULT NULL", 'luas_m2');
ensureColumn('ruang', 'lantai_ke', "INT(11) DEFAULT 1", 'luas_plester_m2');
ensureColumn('ruang', 'keterangan', "TEXT DEFAULT NULL", 'kapasitas');

ensureColumn('sarpras', 'bk_id', "INT NULL COMMENT 'Ref to Book Classification'", 'kategori_id');
ensureColumn('sarpras', 'kepemilikan', "VARCHAR(50) DEFAULT 'Milik Sendiri'", 'sumber_dana');
ensureColumn('sarpras', 'jenis_sarana', "VARCHAR(100) DEFAULT NULL", 'kepemilikan');
ensureColumn('sarpras', 'no_polisi', "VARCHAR(20) DEFAULT NULL", 'jenis_sarana');
ensureColumn('sarpras', 'no_bpkb', "VARCHAR(30) DEFAULT NULL", 'no_polisi');
ensureColumn('sarpras', 'alamat', "TEXT DEFAULT NULL", 'no_bpkb');
ensureColumn('sarpras', 'keterangan', "TEXT DEFAULT NULL", 'kondisi_rusak_berat');
ensureColumn('sarpras', 'grup_pintasan', "VARCHAR(50) DEFAULT NULL");

ensureColumn('sarpras_pj', 'user_id', "INT NULL", 'nip');
ensureColumn('sarpras_pj', 'jabatan', "VARCHAR(100) DEFAULT NULL", 'nip');
ensureColumn('sarpras_pj', 'created_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

ensureColumn('sarpras_peminjaman', 'jabatan', "VARCHAR(255) DEFAULT NULL", 'nama_peminjam');
ensureColumn('sarpras_peminjaman', 'no_hp', "VARCHAR(50) DEFAULT NULL", 'jabatan');
ensureColumn('sarpras_peminjaman', 'asal_unit', "VARCHAR(150) DEFAULT NULL", 'no_hp');
ensureColumn('sarpras_peminjaman', 'nama_kegiatan', "VARCHAR(255) DEFAULT NULL", 'asal_unit');
ensureColumn('sarpras_peminjaman', 'kondisi_sebelum', "TEXT DEFAULT NULL", 'jumlah');
ensureColumn('sarpras_peminjaman', 'kondisi_sesudah', "TEXT DEFAULT NULL", 'kondisi_sebelum');
ensureColumn('sarpras_peminjaman', 'tanggal_kembali_rencana', "DATE DEFAULT NULL", 'tanggal_pinjam');
ensureColumn('sarpras_peminjaman', 'tanggal_kembali_aktual', "DATE DEFAULT NULL", 'tanggal_kembali_rencana');
ensureColumn('sarpras_peminjaman', 'catatan', "TEXT DEFAULT NULL", 'status');
ensureColumn('sarpras_peminjaman', 'updated_by', "INT DEFAULT NULL");

ensureColumn('sarpras_perbaikan', 'berita_acara_id', "INT NULL", 'sarpras_id');
ensureColumn('sarpras_perbaikan', 'tanggal_selesai', "DATE DEFAULT NULL", 'tanggal');
ensureColumn('sarpras_perbaikan', 'biaya', "DECIMAL(15,2) DEFAULT 0", 'tanggal_selesai');
ensureColumn('sarpras_perbaikan', 'jumlah', "INT DEFAULT 1", 'biaya');
ensureColumn('sarpras_perbaikan', 'deskripsi', "TEXT DEFAULT NULL", 'jumlah');
ensureColumn('sarpras_perbaikan', 'updated_by', "INT DEFAULT NULL", 'status');

ensureColumn('sarpras_roles', 'custom_role_id', "INT NULL", 'user_id');
ensureColumn('sarpras_roles', 'created_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
ensureColumn('sarpras_roles', 'updated_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

ensureColumn('sarpras_roles_def', 'created_at', "TIMESTAMP DEFAULT CURRENT_TIMESTAMP");

ensureColumn('kategori_sarpras', 'created_at', "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");

// Fix sarpras_periodik column names (migration had kondisi_rr/kondisi_rb but code uses full names)
ensureColumn('sarpras_periodik', 'kondisi_rusak_ringan', "INT DEFAULT NULL");
ensureColumn('sarpras_periodik', 'kondisi_rusak_berat', "INT DEFAULT NULL");

// Modify sarpras_perbaikan status ENUM to include 'Penghapusan'
try {
    $pdo->exec("ALTER TABLE `sarpras_perbaikan` MODIFY COLUMN `status` ENUM('Diajukan', 'Proses', 'Selesai', 'Batal', 'Penghapusan') DEFAULT 'Diajukan'");
    out('mod', 'MODIFY', "sarpras_perbaikan.status ENUM updated (added Penghapusan) ✓");
} catch (PDOException $e) {
    // Already correct or table doesn't exist
}

// Remove obsolete columns from ruang (if they exist from old migrations)
try {
    $c1 = $pdo->query("SHOW COLUMNS FROM ruang LIKE 'penanggung_jawab'")->fetch();
    if ($c1) { $pdo->exec("ALTER TABLE ruang DROP COLUMN penanggung_jawab"); out('warn', 'DROP', "Obsolete ruang.penanggung_jawab removed"); }
    $c2 = $pdo->query("SHOW COLUMNS FROM ruang LIKE 'nip_penanggung_jawab'")->fetch();
    if ($c2) { $pdo->exec("ALTER TABLE ruang DROP COLUMN nip_penanggung_jawab"); out('warn', 'DROP', "Obsolete ruang.nip_penanggung_jawab removed"); }
} catch (PDOException $e) { /* OK */ }

// ============================================================
// SECTION 5: E-XAM CARD MODULE TABLES (5 tables)
// ============================================================
echo "\n<span class=\"section-title\">📝 5. E-XAM CARD MODULE (5 tables)</span>\n";

ensureTable('xam_exams', "CREATE TABLE IF NOT EXISTS `xam_exams` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `academic_year_id` INT(11) UNSIGNED NOT NULL,
    `exam_name` VARCHAR(150) NOT NULL,
    `exam_start_date` DATE NOT NULL,
    `exam_end_date` DATE NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `card_template` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_xam_exam_year` (`academic_year_id`),
    CONSTRAINT `fk_xam_exam_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('xam_exam_settings', "CREATE TABLE IF NOT EXISTS `xam_exam_settings` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `exam_id` INT(11) UNSIGNED NOT NULL,
    `letter_manual_no` VARCHAR(30) DEFAULT NULL,
    `letter_code` VARCHAR(120) NOT NULL DEFAULT 'I04.1/SMA.WH1',
    `letter_date` DATE DEFAULT NULL,
    `sign_date` DATE DEFAULT NULL,
    `headmaster_user_id` INT(11) UNSIGNED DEFAULT NULL,
    `headmaster_name` VARCHAR(150) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_xam_setting_exam` (`exam_id`),
    KEY `idx_xam_headmaster` (`headmaster_user_id`),
    CONSTRAINT `fk_xam_setting_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_xam_setting_headmaster` FOREIGN KEY (`headmaster_user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('xam_exam_classes', "CREATE TABLE IF NOT EXISTS `xam_exam_classes` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `exam_id` INT(11) UNSIGNED NOT NULL,
    `kelas` VARCHAR(50) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_xam_exam_class` (`exam_id`, `kelas`),
    KEY `idx_xam_exam_class_exam` (`exam_id`),
    CONSTRAINT `fk_xam_exam_class_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

ensureTable('xam_exam_students', "CREATE TABLE IF NOT EXISTS `xam_exam_students` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `exam_id` INT(11) UNSIGNED NOT NULL,
    `student_id` INT(11) UNSIGNED NOT NULL,
    `ruang_ujian` VARCHAR(100) DEFAULT NULL,
    `username` VARCHAR(60) NOT NULL,
    `password_hash` VARCHAR(255) DEFAULT NULL,
    `password_plain` VARCHAR(80) DEFAULT NULL,
    `status` ENUM('OKE','DITANGGUHKAN') NOT NULL DEFAULT 'DITANGGUHKAN',
    `suspension_note` VARCHAR(255) DEFAULT 'Silakan hubungi Wali Kelas / Waka. Kesiswaan',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_xam_exam_student` (`exam_id`, `student_id`),
    KEY `idx_xam_exam_student_exam` (`exam_id`),
    KEY `idx_xam_exam_student_status` (`status`),
    CONSTRAINT `fk_xam_exam_student_exam` FOREIGN KEY (`exam_id`) REFERENCES `xam_exams`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_xam_exam_student_student` FOREIGN KEY (`student_id`) REFERENCES `students`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Bug Fix: xam_teacher_access was MISSING from master migrate.php!
ensureTable('xam_teacher_access', "CREATE TABLE IF NOT EXISTS `xam_teacher_access` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `access_role` VARCHAR(50) NOT NULL DEFAULT 'wali_kelas',
    `kelas` VARCHAR(50) NOT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_xam_user_id` (`user_id`),
    KEY `idx_xam_kelas` (`kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Xam column evolutions
ensureColumn('xam_exams', 'card_template', "VARCHAR(255) DEFAULT NULL", 'status');

// ============================================================
// SECTION 6: E-PERFORMANCE MODULE TABLES (12 tables)
// ============================================================
echo "\n<span class=\"section-title\">📊 6. E-PERFORMANCE MODULE (12 tables)</span>\n";

ensureTable('perf_ptk', "CREATE TABLE IF NOT EXISTS `perf_ptk` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `niy` VARCHAR(30) NOT NULL,
    `nama` VARCHAR(150) NOT NULL,
    `tmt` DATE DEFAULT NULL,
    `tempat_lahir` VARCHAR(100) DEFAULT NULL,
    `tgl_lahir` DATE DEFAULT NULL,
    `jabatan` VARCHAR(100) DEFAULT NULL,
    `mata_pelajaran` VARCHAR(150) DEFAULT NULL,
    `jenis_ptk` VARCHAR(100) NOT NULL DEFAULT '-',
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_niy` (`niy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_users', "CREATE TABLE IF NOT EXISTS `perf_users` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `perf_ptk_id` INT(11) UNSIGNED DEFAULT NULL,
    `nama_lengkap` VARCHAR(150) NOT NULL,
    `role` ENUM('admin','kepsek','guru','tu','it','pustakawan','siswa') NOT NULL,
    `eportal_user_id` INT(11) UNSIGNED DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    KEY `idx_ptk` (`perf_ptk_id`),
    KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_siswa', "CREATE TABLE IF NOT EXISTS `perf_siswa` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama_siswa` VARCHAR(150) NOT NULL,
    `kelas` VARCHAR(30) NOT NULL,
    `username` VARCHAR(50) DEFAULT NULL,
    `password_plain` VARCHAR(50) DEFAULT NULL,
    `perf_user_id` INT(11) UNSIGNED DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_kelas` (`kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_periode', "CREATE TABLE IF NOT EXISTS `perf_periode` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama_periode` VARCHAR(100) NOT NULL,
    `tahun_ajaran` VARCHAR(20) NOT NULL,
    `semester` ENUM('1','2') NOT NULL DEFAULT '1',
    `tgl_mulai` DATE DEFAULT NULL,
    `tgl_selesai` DATE DEFAULT NULL,
    `status` ENUM('draft','aktif','selesai') NOT NULL DEFAULT 'draft',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_instrumen', "CREATE TABLE IF NOT EXISTS `perf_instrumen` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `kode` VARCHAR(20) NOT NULL,
    `kategori` ENUM('kepsek','sejawat','diri','siswa') NOT NULL,
    `target_jabatan` VARCHAR(255) NOT NULL DEFAULT 'guru',
    `target_dinilai` VARCHAR(255) NOT NULL DEFAULT 'Semua',
    `pertanyaan` TEXT NOT NULL,
    `urutan` INT(5) NOT NULL DEFAULT 0,
    `bobot` DECIMAL(5,2) NOT NULL DEFAULT 1.00,
    `is_manual` TINYINT(1) NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_kategori` (`kategori`, `target_jabatan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_sampling', "CREATE TABLE IF NOT EXISTS `perf_sampling` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `perf_siswa_id` INT(11) UNSIGNED NOT NULL,
    `periode_id` INT(11) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_sampling` (`perf_siswa_id`, `periode_id`),
    KEY `idx_periode` (`periode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_penugasan_sejawat', "CREATE TABLE IF NOT EXISTS `perf_penugasan_sejawat` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `periode_id` INT(11) UNSIGNED NOT NULL,
    `penilai_ptk_id` INT(11) UNSIGNED NOT NULL,
    `dinilai_ptk_id` INT(11) UNSIGNED NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_penugasan` (`periode_id`, `penilai_ptk_id`, `dinilai_ptk_id`),
    KEY `idx_penilai` (`penilai_ptk_id`),
    KEY `idx_dinilai` (`dinilai_ptk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_penilaian', "CREATE TABLE IF NOT EXISTS `perf_penilaian` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `periode_id` INT(11) UNSIGNED NOT NULL,
    `penilai_type` ENUM('kepsek','guru','tu','it','pustakawan','siswa') NOT NULL,
    `penilai_id` INT(11) UNSIGNED NOT NULL,
    `dinilai_ptk_id` INT(11) UNSIGNED NOT NULL,
    `instrumen_id` INT(11) UNSIGNED NOT NULL,
    `nilai` TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1=Kurang, 2=Cukup, 3=Baik, 4=Amat Baik',
    `catatan` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_periode_dinilai` (`periode_id`, `dinilai_ptk_id`),
    KEY `idx_penilai` (`penilai_type`, `penilai_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_progress', "CREATE TABLE IF NOT EXISTS `perf_progress` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `periode_id` INT(11) UNSIGNED NOT NULL,
    `penilai_type` ENUM('kepsek','guru','tu','it','pustakawan','siswa') NOT NULL,
    `penilai_id` INT(11) UNSIGNED NOT NULL,
    `target_ptk_id` INT(11) UNSIGNED NOT NULL,
    `status` ENUM('belum','selesai') NOT NULL DEFAULT 'belum',
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_progress` (`periode_id`, `penilai_type`, `penilai_id`, `target_ptk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('perf_sessions', "CREATE TABLE IF NOT EXISTS `perf_sessions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `perf_user_id` INT(11) UNSIGNED NOT NULL,
    `token` VARCHAR(128) NOT NULL,
    `expired_at` DATETIME NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_token` (`token`),
    KEY `idx_user` (`perf_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Bug Fix: perf_penilaian_manual was MISSING from master migrate.php!
ensureTable('perf_penilaian_manual', "CREATE TABLE IF NOT EXISTS `perf_penilaian_manual` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `periode_id` INT(11) NOT NULL,
    `ptk_id` INT(11) NOT NULL,
    `data` LONGTEXT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_periode_ptk` (`periode_id`, `ptk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// Bug Fix: perf_siswa_guru was MISSING — only created by run_db.php!
ensureTable('perf_siswa_guru', "CREATE TABLE IF NOT EXISTS `perf_siswa_guru` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `perf_siswa_id` INT(11) UNSIGNED NOT NULL,
    `perf_ptk_id` INT(11) UNSIGNED NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_siswa_guru` (`perf_siswa_id`, `perf_ptk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Performance column evolutions
// Fix: jenis_ptk should be VARCHAR(100), not ENUM (from migratev7)
modifyColumn('perf_ptk', 'jenis_ptk', "VARCHAR(100) NOT NULL DEFAULT '-'");

// Sync jenis_ptk data from users.tupoksi (from migratev7)
try {
    $stmt = $pdo->query("
        UPDATE perf_ptk p
        JOIN users u ON p.niy = u.username
        SET p.jenis_ptk = IF(u.tupoksi IS NULL OR u.tupoksi = '' OR u.tupoksi = '-', 'guru', u.tupoksi)
        WHERE p.jenis_ptk = '' OR p.jenis_ptk = '-' OR p.jenis_ptk IS NULL
    ");
    $rowCount = $stmt->rowCount();
    if ($rowCount > 0) {
        out('ok', 'SYNC', "Synced $rowCount tupoksi records from users → perf_ptk ✓");
    }
} catch (PDOException $e) {
    // OK if perf_ptk is empty
}

// ============================================================
// SECTION 7: DEFAULT DATA SEEDING
// ============================================================
echo "\n<span class=\"section-title\">🌱 7. DEFAULT DATA SEEDING</span>\n";

// Seed academic year if empty
try {
    $countYears = (int) $pdo->query("SELECT COUNT(*) FROM academic_years")->fetchColumn();
    if ($countYears === 0) {
        $year = ((int) date('n') >= 7) ? (int) date('Y') : (int) date('Y') - 1;
        $label = $year . '/' . ($year + 1);
        $stmt = $pdo->prepare("INSERT INTO academic_years (tahun_ajaran, semester, is_active) VALUES (?, '1', 1)");
        $stmt->execute([$label]);
        $activeId = $pdo->lastInsertId();
        upsert_setting('tahun_ajaran_aktif', $label, 'text', 'Tahun ajaran aktif global');
        upsert_setting('semester_aktif', '1', 'text', 'Semester aktif global');
        upsert_setting('academic_year_id_aktif', (string) $activeId, 'number', 'ID tahun ajaran aktif global');
        out('ok', 'SEED', "Default academic year `$label` created ✓");
        $stats['seeds_applied']++;
    } else {
        out('skip', 'SKIP', "Academic year already exists ($countYears records)");
    }
} catch (PDOException $e) {
    out('err', 'ERR', "Academic year seed: " . htmlspecialchars($e->getMessage()));
    $stats['errors']++;
}

// Seed core settings
upsert_setting('nama_sekolah', get_setting('nama_sekolah', 'E-Portal Sekolah'), 'text', 'Nama sekolah yang ditampilkan');
upsert_setting('icon_sekolah', get_setting('icon_sekolah', ''), 'file', 'Path icon/logo sekolah');
upsert_setting('kepala_sekolah', get_setting('kepala_sekolah', get_setting('sarpras_kepala_sekolah', '')), 'text', 'Nama kepala sekolah untuk surat');
upsert_setting('kop_surat', get_setting('kop_surat', ''), 'file', 'Path kop surat global untuk semua modul');
out('ok', 'SEED', "Core settings ensured ✓");
$stats['seeds_applied']++;

// Seed modules
$modulesSeeds = [
    [
        'nama_modul' => 'E-Graduation',
        'slug' => 'e-graduation',
        'deskripsi' => 'Manajemen kelulusan dan nilai akhir siswa',
        'icon_svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10.5 12 5 2 10.5 12 16l10-5.5Z"/><path d="M6 13v4c2 1.5 10 1.5 12 0v-4"/><path d="M12 16v5"/><path d="M8 21h8"/></svg>',
        'url_path' => 'modules/e-graduation/',
        'color' => '#0F766E',
        'urutan' => 4,
    ],
    [
        'nama_modul' => 'E-Xam Card',
        'slug' => 'e-xam-card',
        'deskripsi' => 'Manajemen kartu ujian siswa',
        'icon_svg' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10"/><path d="M7 12h10"/><path d="M7 16h6"/></svg>',
        'url_path' => 'modules/e-xam-card/',
        'color' => '#0F766E',
        'urutan' => 5,
    ],
];

foreach ($modulesSeeds as $mod) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO modules (nama_modul, slug, deskripsi, icon_svg, url_path, color, urutan, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE
                nama_modul = VALUES(nama_modul),
                deskripsi = VALUES(deskripsi),
                icon_svg = VALUES(icon_svg),
                url_path = VALUES(url_path),
                color = VALUES(color),
                status = VALUES(status)
        ");
        $stmt->execute([$mod['nama_modul'], $mod['slug'], $mod['deskripsi'], $mod['icon_svg'], $mod['url_path'], $mod['color'], $mod['urutan']]);
        out('ok', 'SEED', "Module `{$mod['nama_modul']}` ensured ✓");
        $stats['seeds_applied']++;
    } catch (PDOException $e) {
        out('err', 'ERR', "Module `{$mod['nama_modul']}` seed failed: " . htmlspecialchars($e->getMessage()));
        $stats['errors']++;
    }
}

// Seed referensi data
$refs = [
    ['tupoksi', 'Guru Mata Pelajaran', 'Tugas pokok guru'],
    ['tupoksi', 'Wali Kelas', 'Tugas tambahan guru'],
    ['tupoksi', 'Pembina Ekstrakurikuler', 'Tugas tambahan guru'],
    ['jabatan', 'Guru', 'Jabatan guru'],
    ['jabatan', 'Wali Kelas', 'Jabatan/tugas guru'],
    ['jabatan', 'Kepala Sekolah', 'Jabatan struktural'],
    ['jabatan', 'Wakil Kepala Sekolah', 'Jabatan struktural'],
    ['status_guru', 'PNS', 'Status kepegawaian guru'],
    ['status_guru', 'PPPK', 'Status kepegawaian guru'],
    ['status_guru', 'GTY', 'Status kepegawaian guru'],
    ['status_guru', 'GTT', 'Status kepegawaian guru'],
    ['status_guru', 'Honorer', 'Status kepegawaian guru'],
    ['jenis_ruang', 'Ruang Kelas', 'Jenis ruangan'],
    ['jenis_ruang', 'Perpustakaan', 'Jenis ruangan'],
    ['jenis_ruang', 'Laboratorium', 'Jenis ruangan'],
    ['jenis_ruang', 'Ruang Guru', 'Jenis ruangan'],
    ['jenis_ruang', 'Ruang Kepsek', 'Jenis ruangan'],
    ['jenis_ruang', 'Ruang Tata Usaha', 'Jenis ruangan'],
    ['jenis_ruang', 'Gudang', 'Jenis ruangan'],
    ['jenis_ruang', 'Kamar Mandi/WC', 'Jenis ruangan'],
    ['jenis_ruang', 'Fasilitas Olahraga', 'Jenis ruangan'],
    ['jenis_ruang', 'Lainnya', 'Jenis ruangan'],
];

try {
    $stmtRef = $pdo->prepare("INSERT INTO sarpras_referensi (kategori, nama, keterangan) SELECT ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM sarpras_referensi WHERE kategori=? AND nama=?)");
    $seeded = 0;
    foreach ($refs as $ref) {
        $stmtRef->execute([$ref[0], $ref[1], $ref[2], $ref[0], $ref[1]]);
        if ($stmtRef->rowCount() > 0) $seeded++;
    }
    if ($seeded > 0) {
        out('ok', 'SEED', "Added $seeded referensi entries ✓");
        $stats['seeds_applied'] += $seeded;
    } else {
        out('skip', 'SKIP', "All referensi entries already exist");
    }
} catch (PDOException $e) {
    out('err', 'ERR', "Referensi seed: " . htmlspecialchars($e->getMessage()));
    $stats['errors']++;
}

// ============================================================
// SECTION 8: E-EXAMINATION MODULE TABLES (9 tables)
// ============================================================
echo "\n<span class=\"section-title\">📝 8. E-EXAMINATION MODULE (9 tables)</span>\n";

ensureTable('exam_mapel', "CREATE TABLE IF NOT EXISTS `exam_mapel` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `nama_mapel` VARCHAR(150) NOT NULL,
    `kode` VARCHAR(20) DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_bank_soal', "CREATE TABLE IF NOT EXISTS `exam_bank_soal` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `mapel_id` INT UNSIGNED NOT NULL,
    `judul` VARCHAR(200) NOT NULL,
    `jenis` ENUM('penilaian','psikologi') NOT NULL DEFAULT 'penilaian',
    `kategori_ujian` VARCHAR(50) DEFAULT NULL,
    `tahun_ajaran` VARCHAR(20) DEFAULT NULL,
    `semester` ENUM('1','2') DEFAULT '1',
    `kelas` VARCHAR(30) DEFAULT NULL,
    `created_by` INT UNSIGNED DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_mapel` (`mapel_id`),
    KEY `idx_jenis` (`jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_soal', "CREATE TABLE IF NOT EXISTS `exam_soal` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `bank_soal_id` INT UNSIGNED NOT NULL,
    `tipe_soal` ENUM('benar_salah','menjodohkan','pilihan_satu','pilihan_banyak','jawaban_singkat','esai') NOT NULL,
    `pertanyaan` TEXT NOT NULL,
    `opsi` JSON DEFAULT NULL,
    `kunci_jawaban` JSON DEFAULT NULL,
    `pembahasan` TEXT DEFAULT NULL,
    `bobot` DECIMAL(5,2) NOT NULL DEFAULT 1.00,
    `gambar` VARCHAR(255) DEFAULT NULL,
    `audio` VARCHAR(255) DEFAULT NULL,
    `urutan` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bank` (`bank_soal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_psikologi_hasil', "CREATE TABLE IF NOT EXISTS `exam_psikologi_hasil` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `bank_soal_id` INT UNSIGNED NOT NULL,
    `kode_hasil` VARCHAR(50) NOT NULL,
    `deskripsi` TEXT NOT NULL,
    `rentang_min` DECIMAL(5,2) NOT NULL DEFAULT 0,
    `rentang_max` DECIMAL(5,2) NOT NULL DEFAULT 100,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bank` (`bank_soal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_ujian', "CREATE TABLE IF NOT EXISTS `exam_ujian` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `judul` VARCHAR(200) NOT NULL,
    `bank_soal_id` INT UNSIGNED NOT NULL,
    `jenis` ENUM('penilaian','psikologi') NOT NULL DEFAULT 'penilaian',
    `durasi_menit` INT NOT NULL DEFAULT 60,
    `acak_soal` TINYINT(1) NOT NULL DEFAULT 0,
    `acak_opsi` TINYINT(1) NOT NULL DEFAULT 0,
    `tampil_nilai` TINYINT(1) NOT NULL DEFAULT 1,
    `token` VARCHAR(10) DEFAULT NULL,
    `tgl_mulai` DATETIME DEFAULT NULL,
    `tgl_selesai` DATETIME DEFAULT NULL,
    `status` ENUM('draft','aktif','selesai') NOT NULL DEFAULT 'draft',
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_bank` (`bank_soal_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_ujian_kelas', "CREATE TABLE IF NOT EXISTS `exam_ujian_kelas` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ujian_id` INT UNSIGNED NOT NULL,
    `kelas` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_ujian_kelas` (`ujian_id`, `kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_sesi', "CREATE TABLE IF NOT EXISTS `exam_sesi` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `ujian_id` INT UNSIGNED NOT NULL,
    `student_id` INT UNSIGNED NOT NULL,
    `waktu_mulai` DATETIME NOT NULL,
    `waktu_selesai` DATETIME DEFAULT NULL,
    `sisa_detik` INT DEFAULT NULL,
    `status` ENUM('berlangsung','selesai','didiskualifikasi') NOT NULL DEFAULT 'berlangsung',
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` TEXT DEFAULT NULL,
    `pelanggaran` INT NOT NULL DEFAULT 0,
    `nilai_akhir` DECIMAL(5,2) DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_sesi` (`ujian_id`, `student_id`),
    KEY `idx_ujian` (`ujian_id`),
    KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_jawaban', "CREATE TABLE IF NOT EXISTS `exam_jawaban` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sesi_id` INT UNSIGNED NOT NULL,
    `soal_id` INT UNSIGNED NOT NULL,
    `jawaban` TEXT DEFAULT NULL,
    `jawaban_voice` VARCHAR(255) DEFAULT NULL,
    `is_ragu` TINYINT(1) NOT NULL DEFAULT 0,
    `skor` DECIMAL(5,2) DEFAULT NULL,
    `ai_feedback` TEXT DEFAULT NULL,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_jawaban` (`sesi_id`, `soal_id`),
    KEY `idx_sesi` (`sesi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

ensureTable('exam_cheat_log', "CREATE TABLE IF NOT EXISTS `exam_cheat_log` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sesi_id` INT UNSIGNED NOT NULL,
    `jenis` VARCHAR(50) NOT NULL,
    `detail` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_sesi` (`sesi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============================================================
// SECTION 9: DATA CLEANUP
// ============================================================
echo "\n<span class=\"section-title\">🧹 9. DATA CLEANUP</span>\n";

// Clean HTML entities in student/user names
$entityFixes = [
    ['&#039;', "'"],
    ['&amp;', '&'],
    ['&quot;', '"'],
    ['&lt;', '<'],
    ['&gt;', '>'],
];
$cleanTables = [
    ['students', ['nama', 'tempat_lahir']],
    ['users', ['nama_lengkap']],
];
$totalCleaned = 0;
foreach ($cleanTables as [$table, $columns]) {
    foreach ($columns as $col) {
        foreach ($entityFixes as [$entity, $char]) {
            try {
                $count = $pdo->exec("UPDATE `$table` SET `$col` = REPLACE(`$col`, '$entity', '$char') WHERE `$col` LIKE '%$entity%'");
                if ($count > 0) {
                    $totalCleaned += $count;
                }
            } catch (Exception $e) { /* OK */ }
        }
    }
}
if ($totalCleaned > 0) {
    out('ok', 'CLEAN', "Fixed $totalCleaned HTML entity issues in student/user names ✓");
} else {
    out('skip', 'SKIP', "No HTML entities to clean");
}

// ============================================================
// SECTION 10: FINAL SUMMARY
// ============================================================
echo "\n<span class=\"section-title\">✅ MIGRATION COMPLETED</span>\n";
echo "<span class=\"info\">Database: " . DB_NAME . " @ " . DB_HOST . "</span>\n";
echo "<span class=\"info\">Time: " . date('Y-m-d H:i:s') . "</span>\n";

?>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card green">
            <div class="value"><?= $stats['tables_created'] ?></div>
            <div class="label">Tables Created</div>
        </div>
        <div class="stat-card blue">
            <div class="value"><?= $stats['columns_added'] ?></div>
            <div class="label">Columns Added</div>
        </div>
        <div class="stat-card purple">
            <div class="value"><?= $stats['columns_modified'] ?></div>
            <div class="label">Columns Modified</div>
        </div>
        <div class="stat-card yellow">
            <div class="value"><?= $stats['indexes_added'] ?></div>
            <div class="label">Indexes Added</div>
        </div>
        <div class="stat-card gray">
            <div class="value"><?= $stats['tables_skipped'] + $stats['columns_skipped'] + $stats['indexes_skipped'] ?></div>
            <div class="label">Already OK (Skipped)</div>
        </div>
        <div class="stat-card <?= $stats['errors'] > 0 ? 'red' : 'green' ?>">
            <div class="value"><?= $stats['errors'] ?></div>
            <div class="label">Errors</div>
        </div>
    </div>

    <div style="text-align: center; padding: 20px 0;">
        <?php if ($stats['errors'] === 0): ?>
            <p style="color: #4ade80; font-size: 18px; font-weight: 700; margin-bottom: 16px;">
                🎉 Semua schema berhasil disinkronkan!
            </p>
        <?php else: ?>
            <p style="color: #f87171; font-size: 18px; font-weight: 700; margin-bottom: 16px;">
                ⚠️ Ada <?= $stats['errors'] ?> error. Periksa log di atas.
            </p>
        <?php endif; ?>

        <p style="color: #f87171; font-size: 13px; margin-bottom: 16px;">
            ⚠️ Demi keamanan, HAPUS file migrate_all.php setelah selesai!
        </p>

        <a href="index.php" class="btn-back">🏠 Buka Dashboard E-Portal</a>
    </div>
</div>
</body>
</html>
