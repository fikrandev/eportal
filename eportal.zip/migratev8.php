<?php
/**
 * Migration V8
 * - Menambahkan kolom periode_id di tabel perf_siswa_guru untuk mendukung penugasan siswa per periode.
 */
require_once __DIR__ . '/api/config.php';

try {
    $pdo = db();
    
    echo "<h2>Migrasi V8: Perbaikan Struktur E-Performance (Data Siswa)</h2>";
    echo "<ul>";
    
    try {
        $pdo->exec("ALTER TABLE `perf_siswa_guru` ADD `periode_id` INT(11) UNSIGNED NOT NULL DEFAULT '0' AFTER `id`");
        echo "<li>[OK] Berhasil menambahkan kolom <code>periode_id</code> pada tabel <code>perf_siswa_guru</code>.</li>";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
            echo "<li>[INFO] Kolom <code>periode_id</code> sudah ada pada tabel <code>perf_siswa_guru</code>.</li>";
        } else {
            echo "<li>[ERR] Gagal menambahkan kolom <code>periode_id</code>: " . htmlspecialchars($e->getMessage()) . "</li>";
        }
    }
    
    // Add index for better performance
    try {
        $pdo->exec("ALTER TABLE `perf_siswa_guru` ADD INDEX `idx_periode` (`periode_id`)");
        echo "<li>[OK] Berhasil menambahkan index <code>idx_periode</code>.</li>";
    } catch (PDOException $e) {
        echo "<li>[INFO] Index <code>idx_periode</code> mungkin sudah ada: " . htmlspecialchars($e->getMessage()) . "</li>";
    }
    
    echo "</ul>";
    echo "<p><b>Migrasi V8 Selesai!</b></p>";
    
} catch (Exception $e) {
    echo "<h3>Error Koneksi Database:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
