<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$ptk_id = 849;
$periode_id = 6;

echo "Expected Evaluators for PTK 849:\n";
// Siswa
$stmtS = $db->query("SELECT perf_siswa_id FROM perf_siswa_guru WHERE perf_ptk_id = 849 AND periode_id = 6");
$siswa_ids = $stmtS->fetchAll(PDO::FETCH_COLUMN);
echo "Siswa: " . count($siswa_ids) . " (IDs: " . implode(',', $siswa_ids) . ")\n";

// Kepsek
$stmtK = $db->query("SELECT id FROM users WHERE tupoksi = 'Kepala Sekolah' AND status = 1");
$kepsek_ids = $stmtK->fetchAll(PDO::FETCH_COLUMN);
echo "Kepsek: " . count($kepsek_ids) . " (IDs: " . implode(',', $kepsek_ids) . ")\n";

// Sejawat
$stmtP = $db->query("SELECT penilai_ptk_id FROM perf_penugasan_sejawat WHERE dinilai_ptk_id = 849 AND periode_id = 6");
$peer_ids = $stmtP->fetchAll(PDO::FETCH_COLUMN);
echo "Sejawat: " . count($peer_ids) . " (IDs: " . implode(',', $peer_ids) . ")\n";

// Diri sendiri = 1

echo "\nActual Evaluators for PTK 849 in perf_penilaian:\n";
$stmtA = $db->query("SELECT DISTINCT penilai_id, penilai_type FROM perf_penilaian WHERE dinilai_ptk_id = 849 AND periode_id = 6");
$actuals = $stmtA->fetchAll(PDO::FETCH_ASSOC);
foreach($actuals as $a) {
    echo $a['penilai_type'] . " ID " . $a['penilai_id'] . "\n";
}
?>
