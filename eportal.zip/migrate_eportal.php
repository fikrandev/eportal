<?php
/**
 * Script Migrasi Database E-Performance
 * Jalankan file ini sekali di browser pada hosting (misal: domainanda.com/migrate_eportal.php)
 * untuk menyesuaikan struktur database (schema) terbaru.
 */

// Membutuhkan koneksi ke database, ambil dari konfigurasi aplikasi utama
require_once __DIR__ . '/api/config.php';

echo "<h1>Migrasi Database E-Performance</h1>";
echo "<ul>";

try {
    $db = db();
    
    // 1. Cek dan Tambah Kolom di tabel perf_instrumen
    echo "<li>Mengecek tabel <b>perf_instrumen</b>... ";
    
    $stmt = $db->query("SHOW COLUMNS FROM perf_instrumen LIKE 'tipe_jawaban'");
    if ($stmt->rowCount() == 0) {
        $db->query("ALTER TABLE perf_instrumen ADD COLUMN tipe_jawaban VARCHAR(20) DEFAULT 'angka' AFTER is_manual");
        $db->query("ALTER TABLE perf_instrumen ADD COLUMN skor_ya DECIMAL(5,2) DEFAULT 100 AFTER tipe_jawaban");
        $db->query("ALTER TABLE perf_instrumen ADD COLUMN skor_tidak DECIMAL(5,2) DEFAULT 0 AFTER skor_ya");
        echo "<b>Berhasil</b> menambah kolom tipe_jawaban, skor_ya, skor_tidak.</li>";
    } else {
        // Cek secara spesifik skor_ya jika tipe_jawaban sudah ada
        $stmtYa = $db->query("SHOW COLUMNS FROM perf_instrumen LIKE 'skor_ya'");
        if ($stmtYa->rowCount() == 0) {
            $db->query("ALTER TABLE perf_instrumen ADD COLUMN skor_ya DECIMAL(5,2) DEFAULT 100 AFTER tipe_jawaban");
            $db->query("ALTER TABLE perf_instrumen ADD COLUMN skor_tidak DECIMAL(5,2) DEFAULT 0 AFTER skor_ya");
            echo "<b>Berhasil</b> menambah kolom skor_ya, skor_tidak.</li>";
        } else {
            echo "<span style='color:green;'>Struktur sudah up-to-date (tidak ada perubahan).</span></li>";
        }
    }

    // 2. Cek dan Tambah Kolom di tabel perf_periode
    echo "<li>Mengecek tabel <b>perf_periode</b>... ";
    $stmtPeriode = $db->query("SHOW COLUMNS FROM perf_periode LIKE 'is_released'");
    if ($stmtPeriode->rowCount() == 0) {
        $db->query("ALTER TABLE perf_periode ADD COLUMN is_released TINYINT(1) DEFAULT 0 AFTER status");
        echo "<b>Berhasil</b> menambah kolom is_released.</li>";
    } else {
        echo "<span style='color:green;'>Struktur sudah up-to-date (tidak ada perubahan).</span></li>";
    }

    echo "</ul>";
    echo "<h3 style='color:green;'>Migrasi Skema Database Selesai!</h3>";
    echo "<p>Struktur database Bapak/Ibu di hosting sekarang sudah siap digunakan untuk fitur-fitur terbaru.</p>";

} catch (PDOException $e) {
    echo "</ul>";
    echo "<h3 style='color:red;'>Terjadi Kesalahan:</h3>";
    echo "<p>" . $e->getMessage() . "</p>";
}
?>
