<?php
require_once __DIR__ . '/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT DISTINCT kategori, target_dinilai FROM perf_instrumen WHERE is_manual = 0 AND periode_id = 6 ORDER BY kategori");
$res = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($res as $r) {
    echo "Kat: {$r['kategori']} | Target: {$r['target_dinilai']}\n";
}
?>
