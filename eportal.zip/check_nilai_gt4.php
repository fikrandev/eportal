<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT * FROM perf_penilaian WHERE nilai > 4");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
?>
