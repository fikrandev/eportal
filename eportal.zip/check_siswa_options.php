<?php
require 'e:/xampp/htdocs/eportal/modules/e-performance/api/config_perf.php';
$db = db();
$stmt = $db->query("SELECT id, pilihan_jawaban FROM perf_instrumen WHERE target_jabatan LIKE '%Siswa%' LIMIT 1");
print_r($stmt->fetch(PDO::FETCH_ASSOC));
?>
